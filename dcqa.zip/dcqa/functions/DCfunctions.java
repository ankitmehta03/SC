package dcqa.functions;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.http.client.ClientProtocolException;
import org.apache.log4j.Logger;
import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Proxy;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.xml.sax.SAXException;
import dcqa.utility.ExcelReadWrite;
import dcqa.utility.KillProcess;
import dcqa.utility.ParseUDL;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.BrowserMobProxyServer;
import net.lightbody.bmp.client.ClientUtil;
import net.lightbody.bmp.mitm.manager.ImpersonatingMitmManager;
import net.lightbody.bmp.proxy.CaptureType;



public class DCfunctions {
	
	public static WebDriver driver,mdriver;
	public static WebDriver pdriver,mpdriver;
	public BrowserMobProxy proxy,mproxy;
	public static String DealerURL;
	public static String LDealerURL;
	public static String OARURL;
	public static String smarttprv;
	public static String smarttsub;
	public static String CPC;
	public static String dcprv;
	public String brnd, sitecheck="false";
	public static String code;
	public String pltfm, lpltfm;
	public static String pacode;
	public int rowcnt,colcnt;
	public static HashSet<String> sitelinks = new HashSet<String>();
	
	String USR_DIR = System.getProperty("user.dir");
	ExcelReadWrite er = new ExcelReadWrite();
	KillProcess kill = new KillProcess();
	final static Logger logger = Logger.getLogger(DCfunctions.class);
	
	public String parsepacode(String pa) throws IOException, EncryptedDocumentException, InvalidFormatException {
		
		
		if (pa.contains(".0")) {
			String str = pa.replace(".0","");
			if(str.length()==1) {
				pa= "0000"+str;
			}
			if(str.length()==2) {
				pa="000"+str;
			}
			if(str.length()==3) {
				pa="00"+str;
			}
			if(str.length()==4) {
				pa="0"+str;
			}
			if(str.length()==5) {
				pa=str;
			}
			
		}
		
		logger.info("PAcode after Parsing: "+pa);
		pacode=pa;
		return pa;
	}
	
	public void parsUDL(String pa, int row) throws ClientProtocolException, IOException, ParserConfigurationException, SAXException, EncryptedDocumentException, InvalidFormatException {
		ParseUDL pars = new ParseUDL();
			driver.manage().deleteAllCookies();			
			OARURL = pars.UDLparser(pa, "oarurl");
			DealerURL = pars.UDLparser(pa, "url");
			LDealerURL = pars.UDLparser(pa, "lurl");
			CPC = pars.UDLparser(pa, "fqc");
			smarttprv = pars.UDLparser(pa, "smarttprovider");
			smarttsub = pars.UDLparser(pa, "smarttsubset");
			dcprv = pars.UDLparser(pa, "dcliveplatform");
			brnd = pars.UDLparser(pa, "brandcode");
			try {
				if(brnd !=null) {
					if (brnd.equals("1")) {
						er.setCellData("Ford", row, 3, "F");
						er.setCellData("Lincoln", row, 3, "F");
						er.setCellData("Ford", row, 1, DealerURL);
						er.setCellData("Lincoln", row, 0, pacode);
					}
					if (brnd.equals("2")) {
						er.setCellData("Lincoln", row, 3, "L");
						er.setCellData("Ford", row, 3, "L");
						er.setCellData("Lincoln", row, 1, LDealerURL);
						er.setCellData("Lincoln", row, 0, pacode);
					}
					if (brnd.equals("3")) {
						
						er.setCellData("Ford", row, 3, "FL");
						er.setCellData("Ford", row, 1, DealerURL);
						er.setCellData("Lincoln", row, 3, "FL");
						er.setCellData("Lincoln", row, 1, LDealerURL);
						er.setCellData("Lincoln", row, 0, pacode);
						
					}
				}
			}catch(Exception e) {
				logger.error("Not able to write in Excel sheet");
			}
				
				logger.info("Smartt subset from UDL is: "+smarttsub);
				logger.info("Dealer URL from UDL is: "+DealerURL);
				logger.info("Lincoln Dealer URL from UDL is: "+LDealerURL);
				logger.info("Dealer Brand is: "+brnd);
		/*System.out.println(getDealerURL());
		System.out.println(OARURL);
		System.out.println(CPC);
		System.out.println(smarttprv);
		System.out.println(smarttsub);
		System.out.println(dcprv);
		System.out.println(brnd);*/
	}
	
	public  WebDriver launchChrome() throws Exception {
		System.setProperty("webdriver.chrome.driver",  USR_DIR+"\\src\\main\\resources\\DClib\\chromedriver.exe");
		if (kill.isProcessRunning("chromedriver.exe")) {
			kill.killProcess("chromedriver.exe");
		}
		ChromeOptions options = new ChromeOptions();
		options.addArguments("disable-infobars");
		driver = new ChromeDriver(options);
		//driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		driver.manage().deleteAllCookies();
		driver.manage().window().maximize();
		//TimeUnit.SECONDS.sleep(1);
		return driver;
		
	}
	
	@SuppressWarnings("deprecation")
	public  WebDriver launchChromeproxy() throws Exception {
		System.setProperty("webdriver.chrome.driver",  USR_DIR+"\\src\\main\\resources\\DClib\\chromedriver.exe");
		 proxy = new BrowserMobProxyServer();
	     proxy.setTrustAllServers(true); 
	     proxy.setChainedProxy(new InetSocketAddress("proxyvipecc.nb.ford.com", 83));
	     proxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
	     proxy.start();
	     proxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
	     proxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT, CaptureType.RESPONSE_BINARY_CONTENT);
	     //proxy.setHarCaptureTypes(CaptureType.getBinaryContentCaptureTypes());
	      Proxy seleniumProxy = ClientUtil.createSeleniumProxy(proxy);
	     
	     DesiredCapabilities capabilities = new DesiredCapabilities();
	     capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
	     capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	     ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-infobars");	
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	       driver = new ChromeDriver(capabilities);
	       driver.manage().deleteAllCookies();
	       driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
			driver.manage().window().maximize();
	       return driver;
	}
	
	@SuppressWarnings("deprecation")
	public  WebDriver launchmChromeproxy() throws Exception {
		System.setProperty("webdriver.chrome.driver",  USR_DIR+"\\src\\main\\resources\\DClib\\chromedriver.exe");
		mproxy = new BrowserMobProxyServer();
	    mproxy.setTrustAllServers(true); 
	     mproxy.setChainedProxy(new InetSocketAddress("proxyvipecc.nb.ford.com", 83));
	     mproxy.setMitmManager(ImpersonatingMitmManager.builder().trustAllServers(true).build());
	     mproxy.start();
	     mproxy.setHarCaptureTypes(CaptureType.getAllContentCaptureTypes());
	     mproxy.enableHarCaptureTypes(CaptureType.REQUEST_CONTENT, CaptureType.RESPONSE_CONTENT);
	      Proxy seleniumProxy = ClientUtil.createSeleniumProxy(mproxy);
	      Map<String, String> mobileEmulation = new HashMap<>();
			mobileEmulation.put("deviceName", "Nexus 5");
	     DesiredCapabilities capabilities = new DesiredCapabilities();
	     capabilities.setCapability(CapabilityType.PROXY, seleniumProxy);
	     capabilities.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	     ChromeOptions options = new ChromeOptions();
			options.addArguments("disable-infobars");	
			options.addArguments("--ignore-certificate-errors");
		    options.addArguments("--allow-insecure-localhost");
			options.setExperimentalOption("mobileEmulation", mobileEmulation);
			capabilities.setCapability(ChromeOptions.CAPABILITY, options);
	       mpdriver = new ChromeDriver(capabilities);
	       mpdriver.manage().deleteAllCookies();
			mpdriver.manage().window().maximize();
	       return mpdriver;
	}
	
	public void launchDealer(String brnds) throws Exception {
		driver.manage().deleteAllCookies();
		try {
			logger.info("Clearing Cache");
			Runtime.getRuntime().exec(USR_DIR+"\\src\\main\\resources\\DClib\\clearcache.exe");	
			
			/*((JavascriptExecutor)driver).executeScript("window.open('about:blank','_blank');"); // removing due to issues
			checkWindowHandle();*/
			if (brnds.equals("1")) {
				logger.info("Launching Ford Dealer: "+DealerURL);
				if((DealerURL != "")&& (DealerURL.length()>10)) {
					sitecheck ="true";
					driver.get(DealerURL);
				}
				
			}
			if (brnds.equals("2")) {
				logger.info("Launching Lincoln Dealer: "+LDealerURL);
				if((LDealerURL != "")&& (LDealerURL.length()>10)) {
					sitecheck ="true";
					driver.get(LDealerURL);
				}
			}
			if (brnds.equals("3")) {
				logger.info("Launching Ford Dealer: "+DealerURL);
				if((DealerURL != "")&& (DealerURL.length()>10)){
					sitecheck ="true";
					driver.get(DealerURL);
				}
			}
			if (brnds.equals("4")) {
				logger.info("Launching Lincoln Dealer: "+LDealerURL);
				if((LDealerURL != "")&& (LDealerURL.length()>10)) {
					sitecheck ="true";
					driver.get(LDealerURL);
				}
			}
			checktrustsite();
			driver.navigate().refresh();
			checkPopup();
			closepopup();
		} catch (TimeoutException e) {
			logger.info("Timeout in loading the Dealer");
			//((JavascriptExecutor)driver).executeScript("window.stop()");
			timeout(brnds);
		}
	}
	
	public String identifyPlatform(int row) throws IOException, EncryptedDocumentException, InvalidFormatException {
		pltfm=null;
		lpltfm=null;
		logger.info("Identifying Platform");
		try {
			String scriptsrc = driver.getPageSource();
			if (scriptsrc.split("[dD]ealeron").length >5) {
				 pltfm = "DO";}
				else if (scriptsrc.split("cdk").length >50) {
					 pltfm = "CDK";}
				else if (scriptsrc.split("ddc").length >50) { 
					 pltfm = "DDC";}
				else if (scriptsrc.split("elite").length >50) {
					 pltfm = "Elite";}
				else if (scriptsrc.split("jazel").length >50) {
					 pltfm = "Jazel";}
				else if (scriptsrc.split("base").length >15) {
					 pltfm = "Base";}				
				else {
					logger.info("Didnt get Platform from Source");
				}
				
			//Excelrt.writeExcel(pltfm, row, 2);			
			logger.info("Platform identified as: "+pltfm);
			if(pltfm==null) {
				String pfm1[]=dcprv.split("-");
				if (brnd.equals("1")) {
					pltfm = pfm1[0].trim();
					if(pltfm.equalsIgnoreCase("Dealeron")) {
						pltfm="DO";
					}
					if(pltfm.equalsIgnoreCase("DealerTrack")) {
						pltfm="Elite";
					}
					if(pltfm.equalsIgnoreCase("ITC")) {
						pltfm="Base";
					}
					logger.info("Platfrom retrived from UDL as: "+pltfm);
				}
				if (brnd.equals("2")) {
					pltfm = pfm1[1].trim();
					if(lpltfm.equalsIgnoreCase("Dealeron")) {
						pltfm="DO";
					}
					if(lpltfm.equalsIgnoreCase("DealerTrack")) {
						pltfm="Elite";
					}
					if(lpltfm.equalsIgnoreCase("ITC")) {
						pltfm="Base";
					}
					logger.info("Platfrom retrived from UDL for Lincon as: "+pltfm);
				}
				if (brnd.equals("3")) {
					lpltfm=null;
					pltfm = pfm1[0].trim();
					if(pltfm.equalsIgnoreCase("Dealeron")) {
						pltfm="DO";
					}
					if(pltfm.equalsIgnoreCase("DealerTrack")) {
						pltfm="Elite";
					}
					if(pltfm.equalsIgnoreCase("ITC")) {
						pltfm="Base";
					}
					logger.info("Platfrom retrived from UDL for ford as: "+pltfm);
					lpltfm = pfm1[1].trim(); 
					if(lpltfm.equalsIgnoreCase("Dealeron")) {
						lpltfm="DO";
					}
					if(lpltfm.equalsIgnoreCase("DealerTrack")) {
						lpltfm="Elite";
					}
					if(lpltfm.equalsIgnoreCase("ITC")) {
						lpltfm="Base";
					}
					logger.info("Platfrom retrived from UDL for Lincoln as: "+lpltfm);
				}
				
				
				
			}
			if(brnd.equals("2")) {
				setExcelData("Lincoln", row, 2, pltfm);
			}
			else {
				setExcelData("Ford", row, 2, pltfm);
			}
			
			if(lpltfm!=null) {
				logger.info("Setting lincoln value to platform");
				pltfm = lpltfm;
				logger.info("Updating Lincoln platform as: "+pltfm);
				setExcelData("Lincoln", row, 2, pltfm);
				
			}
			return pltfm;
			
		} catch (Exception e) {
			logger.error("Identify Platform failed "+e.getClass().getName());
			
			return pltfm;
		}
	}
	
	public void checkWindowHandle() {
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		if (tabs.size()>1) {
			driver.switchTo().window(tabs.get(0));
			driver.close();
		driver.switchTo().window(tabs.get(1));
		driver.manage().deleteAllCookies();
		logger.info("Tab Window Handled");
		}
	}
	
	public void mouseHover(WebElement SP) {
		Actions builder = new Actions(driver);
		builder.moveToElement(SP).perform();
		logger.info("MouseHover on Element");

	}
	
	public void checktrustsite() {
		
		try {
			driver.findElement(By.linkText("Click to Proceed")).click();
			logger.info("Click to Proceed");
		} catch (Exception e) {
			//System.out.println("no Click link");
		}
	}
	
	public void checkPopup() {
		try {
			driver.findElement(By.xpath("//button[@aria-label='Close']")).click();
			logger.info("PopupHandled");
		} catch (Exception e) {
			try {
				driver.findElement(By.xpath("//a[@id='fancybox-close']")).click();
				WebElement Close = driver.findElement(By.xpath("//a[@id='fancybox-overlay']"));
				do {
					logger.info("PopupHandled");
				}
				while(!Close.isDisplayed()); 				
				
			} catch (Exception e1) {
				
			}
		}
	}
	
	public void timeout(String brnds) throws Exception {
		logger.info("Handling Timeout by launching new tab");
		//((JavascriptExecutor)driver).executeScript("window.open('about:blank','_blank');");
		driver.quit();
		launchChrome();
		checkWindowHandle();
		relaunchDealer(brnds);
		}
	
	public void relaunchDealer(String brnds) throws InterruptedException {
		driver.manage().deleteAllCookies();
		try {
			((JavascriptExecutor)driver).executeScript("window.open('about:blank','_blank');");
			checkWindowHandle();
			if (brnds.equals("1")) {
				logger.info("Launching Ford Dealer: "+DealerURL);
				driver.get(DealerURL);
			}
			if (brnds.equals("2")) {
				logger.info("Launching Lincoln Dealer: "+LDealerURL);
				driver.get(LDealerURL);
			}
			if (brnds.equals("3")) {
				logger.info("Launching Ford Dealer: "+DealerURL);
				driver.get(DealerURL);
			}
			if (brnds.equals("4")) {
				logger.info("Launching Lincoln Dealer: "+LDealerURL);
				driver.get(LDealerURL);
			}
			checktrustsite();
			driver.navigate().refresh();
			checkPopup();
		} catch (TimeoutException e) {
			logger.info("Timeout in loading the Dealer again");
			//((JavascriptExecutor)driver).executeScript("window.stop()");
			
		}
	}
	
	public int checkpage() {
			int opc=0;
		try {
			opc = driver.getPageSource().split("Oops").length;
			return opc;
		} catch (Exception e) {
			return opc=0;
		}
	}
	
	public void close() {
		try {
			driver.close();
		} catch (Exception e) {
			//System.out.println("Driver not closed");
		}
	}
	
	public void stndURLSiteMap() {
		driver.navigate().to(DealerURL+"/sitemap.aspx/");
		
	}
	
	public void navigateurl(String param) {
		driver.navigate().to(DealerURL+"/"+param);
		logger.info("Navigating to "+DealerURL+"/"+param);
		
	}
	
	public void stndURLservice(String brnds) {
		logger.info("-----Service appointment URL checking------");
		driver.manage().deleteAllCookies();
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL+"/service-appointment/");
			logger.info("Navigating to "+DealerURL+"/service-appointment/");
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL+"/service-appointment/");
			logger.info("Navigating to "+LDealerURL+"/service-appointment/");
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL+"/service-appointment/");
			logger.info("Navigating to "+DealerURL+"/service-appointment/");
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL+"/service-appointment/");
			logger.info("Navigating to "+LDealerURL+"/service-appointment/");
		}
	}
	
	public void stndURLnewinv(String brnds) {
		logger.info("-----New Inventory URL checking------");
		driver.manage().deleteAllCookies();
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL+"/new-inventory/");
			logger.info("Navigating to "+DealerURL+"/new-inventory/");
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL+"/new-inventory/");
			logger.info("Navigating to "+LDealerURL+"/new-inventory/");
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL+"/new-inventory/");
			logger.info("Navigating to "+DealerURL+"/new-inventory/");
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL+"/new-inventory/");
			logger.info("Navigating to "+LDealerURL+"/new-inventory/");
		}
	}
	public void stndURLusedinv(String brnds) {
		logger.info("-----Used Inventory URL checking------");
		driver.manage().deleteAllCookies();
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL+"/used-inventory/");
			logger.info("Navigating to "+DealerURL+"/used-inventory/");
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL+"/used-inventory/");
			logger.info("Navigating to "+LDealerURL+"/used-inventory/");
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL+"/used-inventory/");
			logger.info("Navigating to "+DealerURL+"/used-inventory/");
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL+"/used-inventory/");
			logger.info("Navigating to "+LDealerURL+"/used-inventory/");
		}
	}
	public void stndURLhours(String brnds) {
		logger.info("-----Hours URL checking------");
		driver.manage().deleteAllCookies();
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL+"/hours/");
			logger.info("Navigating to "+DealerURL+"/hours/");
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL+"/hours/");
			logger.info("Navigating to "+LDealerURL+"/hours/");
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL+"/hours/");
			logger.info("Navigating to "+DealerURL+"/hours/");
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL+"/hours/");
			logger.info("Navigating to "+LDealerURL+"/hours/");
		}
	}
	
	public void movetoelement(WebElement we) {
		int pty = we.getLocation().getY();
		pty=pty/2;
		((JavascriptExecutor)driver).executeScript("scroll(0,"+pty+")");
		logger.info("Move to Element");
	}
	
	public void movetopageend() {
		((JavascriptExecutor) driver)
	    .executeScript("window.scrollTo(0, document.body.scrollHeight)");
		logger.info("Move to Page end");
	}
	
	
	
	public void readExcel(String file) throws Exception {
		er.ExcelRead(USR_DIR+"\\src\\main\\java\\dcqa\\testData\\"+file);
		 try {
			rowcnt = er.getRowCount("Ford");
			 colcnt = er.getColumnCount("Ford");
		} catch (Exception e) {
			logger.info("Not able to get row count- getting rowcount on sheet1");
			rowcnt = er.getRowCount("Sheet1");
		}
		 
	}
	
	public String getExcelData(String SheetName, int rowl, int coll) throws Exception {
		String data = er.getCellData(SheetName, rowl, coll);
		return data;
	}
	
	public boolean setExcelData(String SheetName, int rowl, int coll, String data) throws Exception {
		boolean result = er.setCellData(SheetName, rowl, coll, data);
		return result;
	}
	
	public WebElement adChoices() {
		WebElement adicon = null;
		try {
			adicon = driver.findElement(By.xpath("//a[@id='_bapw-link']"));
			logger.info("Found Adchoices icon");
		} catch (Exception e) {
			logger.error("Cant find icon");
		}
		return adicon;
	}
	
	public WebElement fordprivacy() {
		WebElement prvcy = null;
		try {
			//driver.switchTo().frame("_ev_iframe");
			prvcy = driver.findElement(By.xpath("//a[contains(text(),'Privacy')]"));
		} catch (Exception e) {
			logger.error("Ford Privacy is missing");
		}
		return prvcy;
	}
	
	public WebElement FDLogo() {
		WebElement FDL = null;
		try {
			driver.switchTo().frame("_ev_iframe");
			FDL = driver.findElement(By.xpath("//img[contains(@alt,'4259-20160925212015')]"));
			logger.info("Logo SrC: "+FDL.getAttribute("src"));
		} catch (Exception e) {
			logger.error("FordDirect Logo is missing");
		}
		return FDL;
	}
	
	public boolean privacyverify() {
		boolean check;
		String prvcystmt = null;
		ArrayList<String> tabs = new ArrayList<String> (driver.getWindowHandles());
		if (tabs.size()>1) {			
			driver.switchTo().window(tabs.get(1));
			driver.manage().deleteAllCookies();
			try {
				WebElement txt = driver.findElement(By.xpath("//h4[contains(translate(text(),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'summary')]"));
				prvcystmt = txt.getText();
				if(prvcystmt !=null) {
					logger.info("Privacy page verified with text: "+prvcystmt);
					check = true;
				}
				else {
					check=false;
				}
			} catch (Exception e) {
				logger.error("No Privacy statement page");
				check=false;
			}
			driver.close();
			driver.switchTo().window(tabs.get(0));
		}
		else {
			logger.info("No Privacy Page");
			check = false;
		}
		return check;
	}
	
	public void closepopup() {
		List<WebElement> close = driver.findElements(By.xpath("//*[contains(@class,'cross')]"));
		logger.info("No of Popup to Close: "+close.size());
		for(WebElement cs:close) {
			
				try {
					cs.click();
				} catch (Exception e) {
					System.out.println("Cant click close "+e.getClass().getName());
				}
			
		}
	}
	
	public void extractLinks(String dlrl, WebDriver driver) {
		List<WebElement> links = driver.findElements(By.tagName("a"));		
		sitelinks.clear();	
		logger.info("Creating Site links set for "+dlrl);
        Iterator<WebElement> it = links.iterator();
        while(it.hasNext()){	        	
        		String url = it.next().getAttribute("href");
        		
        		if(url !=null) {
        			if(url.contains(dlrl)) {
        				sitelinks.add(url);
        				//System.out.println(url);
        			}
        		}
        		
        	}
       logger.info("Created Links set with size: "+sitelinks.size());  	 
	}
	
}
