package dcqa.utility;

import java.io.IOException;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.DefaultProxyRoutePlanner;
import org.apache.http.util.EntityUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;
import java.io.StringReader;
import org.xml.sax.InputSource;

public class ParseUDL {
	
private static String udlparam;

public String UDLparser(String pacode, String param) throws ClientProtocolException, IOException, ParserConfigurationException, SAXException {
		
		//HttpHost proxy = new HttpHost("proxyvipecc.nb.ford.com", 83);
		//DefaultProxyRoutePlanner routePlanner = new DefaultProxyRoutePlanner(proxy);
		CloseableHttpClient client = HttpClients.custom()
		       // .setRoutePlanner(routePlanner)
		        .build();
			String UDLurl = "http://classic.fordmapping.com/clients/browse.cgi?client=dealerdirect&ovtype=2&count=1&f_dlrpa="+pacode;
		  HttpGet request = new HttpGet(UDLurl);

		  HttpResponse response = client.execute(request);
		  HttpEntity resEntity = response.getEntity();
		  String xmlresponse = EntityUtils.toString(resEntity);		
		  DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder builder;
	        InputSource is;
	        try {
	            builder = factory.newDocumentBuilder();
	            is = new InputSource(new StringReader(xmlresponse));
	            Document doc = builder.parse(is);
	            NodeList list = doc.getElementsByTagName("param");
	            for (int i = 0; i < list.getLength(); i++) {
	                Element elem = (Element) list.item(i);
	                String attribute = elem.getAttribute("name");
	                if (param.equals(attribute)) {
	                    //System.out.println(elem.getTextContent());
	                	udlparam = elem.getTextContent();
	                	
	                }
	            }
	        } catch (ParserConfigurationException e) {
	        } catch (SAXException e) {
	        } catch (IOException e) {
	        }
	        return udlparam;

	}

}
