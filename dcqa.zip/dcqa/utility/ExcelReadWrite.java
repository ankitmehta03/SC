package dcqa.utility;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.FillPatternType;
import org.apache.poi.ss.usermodel.IndexedColors;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
 
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
 
public class ExcelReadWrite
{
    public FileInputStream fis = null;
    public FileInputStream fiss = null;
    public FileOutputStream fos = null;
    public XSSFWorkbook workbook = null;
    public XSSFWorkbook workbookn = null, workbooknew = null;
    public XSSFSheet sheet = null;
    public XSSFRow row = null;
    public XSSFCell cell = null;
    public String filepath = null;
 
    public void ExcelRead(String xlFilePath) throws Exception
    {
        filepath = xlFilePath;
    	fis = new FileInputStream(filepath);
        workbook = new XSSFWorkbook(fis);
        fis.close();
    }
    
    public void ExcelCreate(String xlFilePath) throws Exception
    {
    	workbookn = new XSSFWorkbook();
    	sheet = workbookn.createSheet("Sheet1");
    	FileOutputStream fileOut = new FileOutputStream(xlFilePath);
    	 workbookn.write(fileOut);
         fileOut.close();
         workbookn.close();
    }
    
    public boolean cellStyle(String sheetName, int rowNum, int colNum) {
    	
    	try {
			sheet = workbook.getSheet(sheetName);
			row = sheet.getRow(rowNum);
			cell = row.getCell(colNum);
			
			CellStyle style = workbook.createCellStyle();
			/*Font font = workbook.createFont();
			font.setColor(IndexedColors.RED1.index);
			style.setFont(font);*/
			style.setFillBackgroundColor(IndexedColors.RED1.getIndex());
			style.setFillPattern(FillPatternType.LEAST_DOTS);			
			cell.setCellStyle(style);
			fos = new FileOutputStream(filepath);
			workbook.write(fos);
			fos.close();
		}  catch (Exception ex)
        {
            ex.printStackTrace();
            return  false;
        }
        return true;
    }
    
    public void CopyBook(String FilePath, String xlFilePath) throws Exception
    {
    	fiss = new FileInputStream(FilePath);
    	workbooknew = new XSSFWorkbook (fiss);
    	XSSFWorkbook workbookn = workbooknew;
    	FileOutputStream fiso = new FileOutputStream(xlFilePath);
    	workbookn.write(fiso);
    	fiso.close();    	
    }
 
    public String getCellData(String sheetName, int rowNum, int colNum)
    {
        try
        {
            int col_Num = colNum;
            sheet = workbook.getSheet(sheetName);
            row = sheet.getRow(0);
            /*for(int i = 0; i < row.getLastCellNum(); i++)
            {
                if(row.getCell(i).getStringCellValue().trim().equals(colName.trim()))
                    col_Num = i;
            }*/
 
            row = sheet.getRow(rowNum);
            cell = row.getCell(col_Num);
 
            if(cell.getCellTypeEnum() == CellType.STRING)
                return cell.getStringCellValue();
            else if(cell.getCellTypeEnum() == CellType.NUMERIC || cell.getCellTypeEnum() == CellType.FORMULA)
            {
                String cellValue = String.valueOf(cell.getNumericCellValue());
                if(HSSFDateUtil.isCellDateFormatted(cell))
                {
                    DateFormat df = new SimpleDateFormat("dd/MM/yy");
                    Date date = cell.getDateCellValue();
                    cellValue = df.format(date);
                }
                return cellValue;
            }else if(cell.getCellTypeEnum() == CellType.BLANK)
                return "";
            else
                return String.valueOf(cell.getBooleanCellValue());
        }
        catch(Exception e)
        {
            //e.printStackTrace();
            return "row "+rowNum+" or column "+colNum +" does not exist  in Excel";
        }
    }
    
    public boolean setCellData(String sheetName,  int rowNum, int colNumber, String value)
    {
        try
        {
            sheet = workbook.getSheet(sheetName);
            if(sheet==null)
            	sheet = workbook.createSheet(sheetName);
            row = sheet.getRow(rowNum);
            if(row==null)
                row = sheet.createRow(rowNum);
 
            cell = row.getCell(colNumber);
            if(cell == null)
                cell = row.createCell(colNumber);
 
            cell.setCellValue(value);
 
            fos = new FileOutputStream(filepath);
            workbook.write(fos);
            fos.close();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
            return  false;
        }
        return true;
    }
    
    public int getRowCount(String sheetName)
    {
        sheet = workbook.getSheet(sheetName);
        int rowCount = sheet.getLastRowNum()+1;
        return rowCount;
    }
  
    public int getColumnCount(String sheetName)
    {
        sheet = workbook.getSheet(sheetName);
        row = sheet.getRow(0);
        int colCount = row.getLastCellNum();
        return colCount;
    }
}