package dcqa.pages;


import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import dcqa.utility.ExcelReadWrite;
import dcqa.functions.DCfunctions;



public class BaseHomePage extends DCfunctions{

	public StringBuilder result;
	public StringBuilder comment;
	ExcelReadWrite er = new ExcelReadWrite();
	final static Logger logger = Logger.getLogger(BaseHomePage.class); 
	
	public void serviceandparts() {
		result = new StringBuilder();
		comment = new StringBuilder();
		logger.info("-----Service appointment from Homepage - service department menu------");				
		try {
			WebElement SP = getServiceMenu();
			mouseHover(SP);
			try {
				WebElement SS = SP.findElement(By.xpath("//a[contains(text(),'Service Department')]"));
				SS.click();
				logger.info("Serivce Department Menu");
			} catch (Exception e3) {
				logger.error("Cant Click on Service Department "+e3.getClass().getSimpleName());
			}	
			checkWindowHandle();
			logger.info("Check for Smartt Frame in Page");
			checkSmartt();
			logger.info("check for Schedule service link and click");
			try {
				driver.findElement(By.xpath("//a[@id='serviceAppmtBtn']")).click();
				logger.info("Service Appointment Link");
				checkWindowHandle();
				getSmartt();
			} catch (Exception e1) {
				try {
					driver.findElement(By.xpath("//img[contains(@src,'button-scheduleservice.jpg')]")).click();
					logger.info("Schedule service Button");
					checkWindowHandle();
					getSmartt();
				} catch (Exception e) {
					try {
						//driver.findElement(By.xpath("//div[@id='content']//following::a[contains(@href,'service') and not(contains(@href,'parts'))]")).click();
						driver.findElement(By.xpath("//div[@id='content']//following::a[contains(text(),'Schedule')]")).click();
						logger.info("Schedule on div Link");
						getSmartt();
					} catch (Exception e2) {
						logger.error("Schedule service not found / cant locate "+e2.getClass().getSimpleName());
						//result.append("false");
					}
					
				}
			}
		} catch (Exception e2) {
			result.append("false");
			logger.error("Schedule service not validated in Service Department page "+e2.getClass().getSimpleName());	
			comment.append("Schedule service not validated in Service Department page\n");
			
		}
		
	}

	public void getSmartt() {
		logger.info("Getting Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			String smarttfrm = smarttframe.getAttribute("src");
			logger.info("-Smartt: "+smarttfrm);
			if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
				result.append("true");
				logger.info("Smartt Frame equals to UDL");
			}
			else {
				result.append("false");
				logger.info("Smartt Frame not equal to UDL");
				comment.append("Smartt Subset not equal to UDL\n");
			}
		} catch (Exception e) {
			logger.error("No Iframe Found");
			result.append("false");
			comment.append("Smartt Not installed\n");
		}
	}
	
	public void checkSmartt() {
		logger.info("Checking Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			if(smarttframe!=null) {
				
				String smarttfrm = smarttframe.getAttribute("src");
				logger.info("->Smartt: "+smarttfrm);
				if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
					result.append("true");
					logger.info("Smartt Frame equals to UDL");
				}
				else {
					result.append("false");
					logger.info("Smartt Frame not equal to UDL");
					comment.append("Smartt Subset not equal to UDL\n");
				}
			} else {
				logger.error("No Smartt Frame in Page");
				
			}
		} catch (Exception e) {
			logger.info("No anothere frame in the Page");
		}
	}
	
	public void smartthome(String brnds) {
		logger.info("----------Service appointment from Homepage------------");
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL);
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL);
		}
		driver.navigate().refresh();
		int SP3 = driver.findElements(By.xpath("//div[@id='vehicle-barrage-layout-1']//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]")).size();
		logger.info("Found Service link "+SP3);
		if(SP3>0) {
			try {
				driver.findElement(By.xpath("//div[@id='vehicle-barrage-layout-1']//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]")).click();
				logger.info("Schedule Service link");
				checkWindowHandle();
				getSmartt();
			} catch (Exception e) {
				logger.info("Extracting URL and Navigate");
				try {
					String homeanc = driver.findElement(By.xpath("//div[@id='vehicle-barrage-layout-1']//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]")).getAttribute("href");
					logger.info("Serviceapp link: "+homeanc);
					driver.navigate().to(homeanc);
					getSmartt();
				} catch (Exception e1) {
					String homeanc = driver.findElement(By.xpath("//div[@id='vehicle-barrage-layout-1']//following::a[contains(@href,'service')][not(contains(@href,'parts'))]")).getAttribute("href");
					logger.info("Service link: "+homeanc);
					driver.navigate().to(homeanc);
					getSmartt();
				}
			}
		}
		
	}

	public String validateSamrtt(String brnds)  {
		String stresult = null;
		logger.info("Validating Smartt "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
		
	}
	
	public String updateComments() {
		String Comments = comment.toString();
		return Comments;
	}
	
	public WebElement smarttFrame() {
		
		WebElement iframe;
		try {
			iframe = driver.findElement(By.xpath("//iframe[contains(@src,'NAKEDLIME')]"));
			//iframe = driver.findElement(By.xpath("//iframe[contains(@src,'[Nn][Aa][Kk][Ee][Dd][Ll][Ii][Mm][Ee]')]"));
			logger.info("Reynolds Iframe aA");
			
		} catch (Exception e3) {
			try {
				iframe = driver.findElement(By.xpath("//iframe[contains(@src,'cid')]"));
				logger.info("CDK Iframe");
			} catch (Exception e4) {				
					iframe = driver.findElement(By.xpath("//iframe[contains(@src,'nakedlime')]"));
					logger.info("Reynolds Iframe");									
			}
		}
		
		return iframe;
	}
	
	
	public WebElement getServiceMenu() {
		WebElement SP;
		try {
			SP = driver.findElement(By.xpath("//ul[@class='nav']//following::a[contains(text(),'Service')]"));
			logger.info("Service Menu");
		} catch (Exception e) {
			try {
				SP = driver.findElement(By.xpath("//a[@title='Service']"));
			} catch (Exception e1) {
				logger.error("cant find service menu element "+e1.getClass().getName());
				return null;
			}
		}
		return SP;
	}
	
	public void scheduleservice() {
		try {
			logger.info("----------Service appointment from Homepage - Schedule service----------");	
			WebElement SP1 = getServiceMenu();
			mouseHover(SP1);
			int SSc = SP1.findElements(By.xpath("//a[contains(text(),'Schedule Service')]")).size();
			logger.info("SSl count "+SSc);
			if(SSc>0) {
				SP1.findElement(By.xpath("//a[contains(text(),'Schedule Service')]")).click();	
				checkWindowHandle();
				getSmartt();
			}
			else {
				logger.error("Schedule Service is not found");
				comment.append("Schedule Service from Menu - not validated\n");
			}
		} catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("Schedule Service from Menu - not validated\n");
		}
		
	}
	
	
	public void OARURL() {
		result = new StringBuilder();
		comment = new StringBuilder();		
		try {
			logger.info("------Validation of OAR from Service Menu-------");
			WebElement SP1 =  getServiceMenu();
			mouseHover(SP1);
			
			try {
				driver.findElement(By.xpath("//a[contains(text(),'Owner')]")).click();
				logger.info("Owner Advantage rewards Click Success - text");
			} catch (Exception e) {
				try {
					driver.findElement(By.xpath("//a[contains(@href,'owner')]")).click();
					logger.info("Owner Advantage rewards Click Success - href");
				} catch (Exception e1) {
					try {
						logger.info("Extracting URL and Navigating");
						String ourl = driver.findElement(By.xpath("//a[contains(text(),'Owner Advantage Rewards')]")).getAttribute("href");
						logger.info("Navigating to: "+ourl);
						driver.navigate().to(ourl);
					} catch (Exception e2) {
						logger.error("Not able to click on Owner Advantage Rewards");
						result.append("false");
						comment.append("Owner Advantage Rewards - Not Validated");
					}
					
				}
				
			}			
			
		}catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			OARURL();
		}
		catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("OAR - not validated\n");
		}
	}
	
	public String verifyOAR(String brnds) {
		logger.info("Verifying OAR URL");
		String oarurl = null;
		try {
			oarurl = driver.findElement(By.xpath("//a[contains(@href,'enroll')]")).getAttribute("href");
			logger.info("OAR URL is: "+oarurl);
			logger.info("From UDL is: "+OARURL);
			if(oarurl.toLowerCase().contains(OARURL.toLowerCase())) {
				result.append("true");
				logger.info("OAR URL equals to UDL");
			}
			else {
				result.append("false");
				logger.info("OAR URL not equal to UDL");
				comment.append("OAR URL Mismatch\n");
				comment.append("OAR from UDL: "+OARURL+" OARURL from site: "+oarurl+"\n");
			}
			
		}catch (Exception e) {
			logger.error("Cant Validate OAR URL "+e.getClass().getName());
			result.append("false");
			String enrollurl =null;
			try {
				enrollurl = driver.findElement(By.xpath("//a[contains(text(),'enroll')]")).getAttribute("href");
				if(enrollurl.contains("enroll")) {
					comment.append("OAR URL - not validated\n");
				}
				else {
					logger.info("Enroll button URL: "+enrollurl);
					comment.append("OAR URL Missing\n");
					
				}
			} catch (Exception e1) {
				logger.info("No Enroll button");
			}
		}
		
		String stresult = null;
		logger.info("Validating OAR "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
	}
	
	
	
	public void servicestndURL(String brnds) {
		stndURLservice(brnds);
		getSmartt();
		
	}
	
}
