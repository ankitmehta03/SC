package dcqa.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import dcqa.utility.ExcelReadWrite;
import dcqa.functions.DCfunctions;


public class JazelHomePage extends DCfunctions {

	public StringBuilder result;
	public StringBuilder comment;
	ExcelReadWrite er = new ExcelReadWrite();
	final static Logger logger = Logger.getLogger(JazelHomePage.class); 
	 
	
	public void serviceandparts() {
		result = new StringBuilder();
		comment = new StringBuilder();
		logger.info("-------Service appointment from Homepage - service department menu--------");				
		try {
			WebElement SP = getServiceMenu();
			mouseHover(SP);
			//WebElement SS = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::a[contains(@href,'/Service')]"));
			//WebElement SS;
			try {
					//WebElement SS = SP.findElement(By.partialLinkText("Service Department"));
					WebElement SS = SP.findElement(By.xpath("//li[contains(@id,'menu-item')]//following::span[contains(text(),'Service Department')]"));
					logger.info("Service Department Menu");
				
					SS.click();
					checktrustsite();
				} catch (Exception e) {
					try {
						SP.click();
						WebElement SS = driver.findElement(By.xpath("//div[contains(@class,'TwoColumnNav')]//following::span[contains(text(),'Service Department')]"));
						logger.info("Mobile Service Department Menu");
						SS.click();
						checktrustsite();
					}
					catch (Exception e3) {
						try {
							WebElement SS = SP.findElement(By.partialLinkText("Service Center"));
							logger.info("Service Center Menu");
							SS.click();
							checktrustsite();
						} catch (Exception e2) {
								logger.error("Cant Click on Service Department "+e2.getClass().getName());
							}
						}
					}
				
					
			checkWindowHandle();
			logger.info("Check for Smartt Frame in Page");
			checkSmartt();
			logger.info("check for Schedule service link and click");
			try {
				WebElement SS1= driver.findElement(By.xpath("//div[@id='row-pagebanner']//following::a[contains(text(),'Schedule')]"));
				logger.info("Schedule text link "+SS1.getAttribute("innerHTML"));
				movetoelement(SS1);
				SS1.click();
				logger.info("Schedule link Click Success");
				checkWindowHandle();
				getSmartt();
			} catch (Exception e1) {
				logger.error("Schedule service not found / cant locate "+e1.getClass().getName());
				result.append("false");
				
			}
		} catch (Exception e2) {
			result.append("false");
			logger.error("Schedule service not validated in Service Department page "+e2.getClass().getName());	
			comment.append("Schedule service not validated in Service Department page\n");
			
		}
		
	
	}

	public void getSmartt() {
		logger.info("Getting Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			String smarttfrm = smarttframe.getAttribute("src");
			logger.info("-Smartt: "+smarttfrm);
			if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
				result.append("true");
				logger.info("->Smartt Frame equals to UDL");
			}
			else {
				result.append("false");
				logger.info("->Smartt Frame not equals to UDL");
				comment.append("Smartt Subset Changed from UDL\n");
			}
		} catch (Exception e) {
			logger.error("No Iframe Found");
			result.append("false");
			comment.append("Smartt Not installed\n");
		}
	}
	
	public void checkSmartt() {
		logger.info("Checking Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			if(smarttframe!=null) {
				
				String smarttfrm = smarttframe.getAttribute("src");
				logger.info("->Smartt: "+smarttfrm);
				if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
					result.append("true");
					logger.info("Smartt Frame equals to UDL");
				}
				else {
					result.append("false");
					logger.info("Smartt Frame not equal to UDL");
					comment.append("Smartt Subset not equal to UDL\n");
				}
			} else {
				logger.error("No Smartt Frame in Page");
				
			}
		} catch (Exception e) {
			logger.info("No anothere frame in the Page");
		}
	}
	
	public void smartthome(String brnds) {
		logger.info("-----Service appointment from Homepage------");
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL);
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL);
		}
		driver.navigate().refresh();
		checkPopup();
		int SP3 = driver.findElements(By.xpath("//div[contains(@class,'the_content_wrapper')]//a[contains(text(),'Schedule')]")).size();
		logger.info("Found Service link "+SP3);
		if(SP3>0) {
			try {
				WebElement hm = driver.findElement(By.xpath("//div[contains(@class,'the_content_wrapper')]//a[contains(text(),'Schedule')]"));
				logger.info(hm.getAttribute("href"));
				mouseHover(hm);
				hm.click();
				checkWindowHandle();
				getSmartt();
			} catch (Exception e) {
				try {
					WebElement hm1 = driver.findElement(By.xpath("//div[contains(@class,'the_content_wrapper')]//following::h2[contains(text(),'Schedule')]"));
					logger.info("Heading Navigation schedule");
					mouseHover(hm1);
					hm1.click();
					checkWindowHandle();
					getSmartt();
				} catch (Exception e1) {
					logger.info("Extracting URL and Navigate");
					String homeanc = driver.findElement(By.xpath("//div[contains(@class,'the_content_wrapper')]//following::a[contains(text(),'Schedule')]")).getAttribute("href");
					logger.info(homeanc);
					driver.navigate().to(homeanc);
					getSmartt();
				}
			}
		}
		if(SP3==0) {
			try {
				WebElement hm1 = driver.findElement(By.xpath("//div[contains(@class,'the_content_wrapper')]//following::img[contains(@src,'service-desktop')]"));
				logger.info("Heading Navigation schedule");
				mouseHover(hm1);
				hm1.click();
				checkWindowHandle();
				getSmartt();
			} catch (Exception e) {
				try {
					logger.error("Heading text Navigation failed looking for Expert Service"+e.getClass().getName());
					WebElement hm1 = driver.findElement(By.xpath("//div[contains(@class,'the_content_wrapper')]//following::a[contains(text(),'Expert Service')]"));
					logger.info("Expert Service Navigation schedule");
					mouseHover(hm1);
					hm1.click();
					checkWindowHandle();
					SchServicelink();
					getSmartt();
				} catch (Exception e1) {
					logger.error("HomePage Validation Failed "+e1.getClass().getName());
					result.append("false");
				}
			}
		}
		
	}

	
	
	public void SchServicelink() {
		logger.info("check for Schedule service link and click");
		try {
			WebElement SS1= driver.findElement(By.xpath("//div[@id='row-pagebanner']//following::a[contains(text(),'Schedule')]"));
			logger.info("Schedule text link "+SS1.getAttribute("innerHTML"));
			movetoelement(SS1);
			SS1.click();
			logger.info("Schedule link Click Success");
			checkWindowHandle();
			
		}catch(NoSuchElementException e1) {
			logger.error("Schedule service link is not present "+e1.getClass().getName());
					
		}
		catch (Exception e1) {
			logger.error("Schedule service not found / cant locate "+e1.getClass().getName());
			result.append("false");
			
		}
	}
	public String validateSamrtt(String brnds)  {
		String stresult = null;
		logger.info("Validating Smartt "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
		
	}
	
	public String updateComments() {
		String Comments = comment.toString();
		return Comments;
	}
	
	public WebElement smarttFrame() {
		
		WebElement iframe = null;
		try {
			iframe = driver.findElement(By.xpath("//iframe[contains(@src,'cid')]"));
			logger.info("CDK Iframe");
			
		} catch (Exception e) {
			try {
				iframe = driver.findElement(By.xpath("//iframe[contains(@src,'NAKEDLIME')]"));
				logger.info("Reynolds Iframe");
				
			} catch (Exception e1) {
				try {
					iframe = driver.findElement(By.xpath("//iframe[@id='fordServiceApptSchedulerIframe']"));
					logger.info("smartt Iframe");
				} catch (Exception e2) {
					try {
						iframe = driver.findElement(By.xpath("//iframe[@id='custom-iframe']"));
						logger.info("custom frame");
						
					} catch (Exception e3) {
						try {
							iframe = driver.findElement(By.xpath("//iframe[@id='ford-service-iframe']"));
							logger.info("ford frame");
						} catch (Exception e4) {
							iframe = driver.findElement(By.xpath("//iframe[contains(@src,'nakedlime')]"));
							logger.info("Reynolds Iframe");
							}
							
						}
					}
				}
				
			}
			
		
		
		return iframe;
	}
	
	
	public WebElement getServiceMenu() {
		WebElement SP;
		try {
			SP = driver.findElement(By.xpath("//li[contains(@class,'menu-item-has-children')]//following::span[contains(text(),'Parts')]"));
			logger.info("Parts & Service link");
		} catch (Exception e) {
			try {
				logger.info("Checking Mobile Menu");
				WebElement mmenu=driver.findElement(By.xpath("//div[contains(@class,'desktop Header__Root')]"));
				String mclass = mmenu.getAttribute("class");
				logger.info("Got the class: "+mclass);
				driver.findElement(By.xpath("//div[@class='"+mclass+"']//following::span[contains(@class,'MenuCrossIcon__Second')]")).click();
				logger.info("Click Success");
				SP = driver.findElement(By.xpath("//div[contains(@class,'TwoColumnNav')]//following::span[contains(text(),'Parts')][contains(.,'Service')]"));
				logger.info("mobile menu link Success");
				
				
			} catch (Exception e1) {
				try {
					SP = driver.findElement(By.xpath("//a[@title='Service']"));
					logger.info("Service title link");
				} catch (Exception e2) {
					logger.error("cant find service menu element "+e2.getClass().getName());
					return null;
				}
				
			}
		}
		return SP;
	}
	
	public void scheduleservice() {
		try {
			logger.info("--------Service appointment from Homepage - Schedule service-------");	
			WebElement SP1 = getServiceMenu();
			mouseHover(SP1);
			
			WebElement SS1;
			try {
				SS1 =  SP1.findElement(By.xpath("//li[contains(@id,'menu-item')]//following::span[contains(text(),'Schedule Service')]"));
				logger.info("Schedule Service text link");
			} catch (Exception e) {
				try {
					SS1 = driver.findElement(By.xpath("//div[contains(@class,'TwoColumnNav')]//following::span[contains(text(),'Schedule Service')]"));
					logger.info("mobile Schedule service link");
				} catch (Exception e1) {
					
					try {
						SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'SERVICE')]//following::a[contains(.,'Schedule Service')]"));
					} catch (Exception e2) {
						SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]//following::a[contains(text(),'Schedule Service')]"));
					}
				}
			}
			movetoelement(SS1);
			mouseHover(SS1);
			SS1.click();
			checkWindowHandle();
			getSmartt();
			
		} catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("Schedule Service from Menu - not validated\n");
		}
		
	}
	
	public void OARURL() {
		result = new StringBuilder();
		comment = new StringBuilder();		
		try {
			logger.info("------Validation of OAR from Service Menu-------");
			WebElement SP1 =  getServiceMenu();
			mouseHover(SP1);
			//SP1.click();
			
			try {
				driver.findElement(By.xpath("//a[contains(text(),'Owner Advantage Rewards')]")).click();
				logger.info("Owner Advantage rewards Click Success - text");
			} catch (Exception e) {
				try {
					driver.findElement(By.xpath("//a[contains(@href,'owner')]")).click();
					logger.info("Owner Advantage rewards Click Success - href");
				} catch (Exception e1) {
					try {
						logger.info("Extracting URL and Navigating");
						String ourl = driver.findElement(By.xpath("//a[contains(text(),'Owner Advantage Rewards')]")).getAttribute("href");
						logger.info("Navigating to: "+ourl);
						driver.navigate().to(ourl);
					} catch (Exception e2) {
						logger.error("Not able to click on Owner Advantage Rewards");
						result.append("false");
						comment.append("Owner Advantage Rewards - Not Validated");
					}
					
				}
				
			}			
			
		}catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			OARURL();
		}
		catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("OAR - not validated\n");
		}
	}
	
	public String verifyOAR(String brnds) {
		logger.info("Verifying OAR URL");
		String oarurl = null;
		try {
			oarurl = driver.findElement(By.xpath("//a[contains(@href,'enroll')]")).getAttribute("href");
			logger.info("OAR URL is: "+oarurl);
			logger.info("From UDL is: "+OARURL);
			if(oarurl.toLowerCase().contains(OARURL.toLowerCase())) {
				result.append("true");
				logger.info("OAR URL equals to UDL");
			}
			else {
				result.append("false");
				logger.info("OAR URL not equal to UDL");
				comment.append("OAR URL Mismatch\n");
				comment.append("OAR from UDL: "+OARURL+" OARURL from site: "+oarurl+"\n");
			}
			
		}catch (Exception e) {
			logger.error("Cant Validate OAR URL "+e.getClass().getName());
			result.append("false");
			String enrollurl =null;
			try {
				enrollurl = driver.findElement(By.xpath("//a[contains(text(),'enroll')]")).getAttribute("href");
				if(enrollurl.contains("enroll")) {
					comment.append("OAR URL - not validated\n");
				}
				else {
					logger.info("Enroll button URL: "+enrollurl);
					comment.append("OAR URL Missing\n");
					
				}
			} catch (Exception e1) {
				logger.info("No Enroll button");
			}
		}
		
		String stresult = null;
		logger.info("Validating OAR "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
	}
	
	
	
	public void servicestndURL(String brnds) {
		stndURLservice(brnds);
		getSmartt();
		
	}

}
