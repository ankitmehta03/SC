package dcqa.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import dcqa.utility.ExcelReadWrite;
import dcqa.functions.DCfunctions;


public class CDKHomePage extends DCfunctions {

	public StringBuilder result;
	public StringBuilder comment;
	ExcelReadWrite er = new ExcelReadWrite();
	final static Logger logger = Logger.getLogger(CDKHomePage.class); 
	 
	
	public void serviceandparts() {
		result = new StringBuilder();
		comment = new StringBuilder();
		logger.info("-------Service appointment from Homepage - service department menu--------");				
		try {
			WebElement SP = getServiceMenu();
			mouseHover(SP);
			//WebElement SS = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::a[contains(@href,'/Service')]"));
			//WebElement SS;
			try {
					WebElement SS = SP.findElement(By.partialLinkText("Service Center"));
					logger.info("Service Center Menu");
					SS.click();
					checktrustsite();
				} catch (Exception e) {
					try {
						WebElement SS = SP.findElement(By.partialLinkText("Ford Service"));
						logger.info("Ford Service Menu");
						SS.click();
						checktrustsite();
					}
					catch (Exception e3) {
						try {
							WebElement SS = SP.findElement(By.partialLinkText("Service Department"));
							logger.info("Service Department Menu");
							SS.click();
							checktrustsite();
						} catch (Exception e2) {
							try {
								WebElement SS = SP.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]//following::a[contains(@href,'/ServiceAndParts')]"));
								logger.info("Service and Parts Menu");
								SS.click();
								checktrustsite();
							} catch (Exception e1) {
								logger.error("Cant Click on Service Department "+e1.getClass().getName());
							}
						}
					}
				
				}	
			checkWindowHandle();
			logger.info("Check for Smartt Frame in Page");
			checkSmartt();
			logger.info("check for Schedule service link and click");
			try {
				WebElement SS1= driver.findElement(By.xpath("//div[@class='content']//following::a[contains(@title,'Schedule')]"));
				movetoelement(SS1);
				SS1.click();
				checkWindowHandle();
				getSmartt();
			} catch (Exception e1) {
				try {
					WebElement SS1 = driver.findElement(By.xpath("//img[contains(@src,'button-scheduleservice.jpg')]"));
					movetoelement(SS1);
					SS1.click();
					checkWindowHandle();
					getSmartt();
				} catch (Exception e) {
					try {
						//driver.findElement(By.xpath("//div[@id='content']//following::a[contains(@href,'service') and not(contains(@href,'parts'))]")).click();
						driver.findElement(By.xpath("//a[@id='serviceAppmtBtn']")).click();
						checkWindowHandle();
						getSmartt();
					} catch (Exception e2) {
						logger.error("Schedule service not found / cant locate "+e2.getClass().getName());
						result.append("false");
					}
					
				}
			}
		} catch (Exception e2) {
			result.append("false");
			logger.error("Schedule service not validated in Service Department page "+e2.getClass().getName());	
			comment.append("Schedule service not validated in Service Department page\n");
			
		}
		
	
	}

	public void getSmartt() {
		logger.info("Getting Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			String smarttfrm = smarttframe.getAttribute("src");
			logger.info("-Smartt: "+smarttfrm);
			if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
				result.append("true");
				logger.info("->Smartt Frame equals to UDL");
			}
			else {
				result.append("false");
				logger.info("->Smartt Frame not equals to UDL");
				comment.append("Smartt Subset Changed from UDL\n");
			}
		} catch (Exception e) {
			logger.error("No Iframe Found");
			result.append("false");
			comment.append("Smartt Not installed\n");
		}
	}
	
	public void checkSmartt() {
		logger.info("Checking Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			if(smarttframe!=null) {
				
				String smarttfrm = smarttframe.getAttribute("src");
				logger.info("->Smartt: "+smarttfrm);
				if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
					result.append("true");
					logger.info("Smartt Frame equals to UDL");
				}
				else {
					result.append("false");
					logger.info("Smartt Frame not equal to UDL");
					comment.append("Smartt Subset not equal to UDL\n");
				}
			} else {
				logger.error("No Smartt Frame in Page");
				
			}
		} catch (Exception e) {
			logger.info("No anothere frame in the Page");
		}
	}
	
	public void smartthome(String brnds) {
		logger.info("-----Service appointment from Homepage------");
		if (brnds.equals("1")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("2")) {
			driver.navigate().to(LDealerURL);
		}
		if (brnds.equals("3")) {
			driver.navigate().to(DealerURL);
		}
		if (brnds.equals("4")) {
			driver.navigate().to(LDealerURL);
		}
		driver.navigate().refresh();
		int SP3 = driver.findElements(By.xpath("//div[@class='content']//following::a[contains(@title,'Schedule')]")).size();
		logger.info("Found Service link "+SP3);
		if(SP3>0) {
			try {
				WebElement hm = driver.findElement(By.xpath("//div[@class='content']//following::a[contains(@title,'Schedule')]"));
				logger.info(hm.getAttribute("href"));
				mouseHover(hm);
				hm.click();
				checkWindowHandle();
				getSmartt();
			} catch (Exception e) {
				logger.info("Extracting URL and Navigate");
				String homeanc = driver.findElement(By.xpath("//div[@class='content']//following::a[contains(@href,'ServiceApp')]")).getAttribute("href");
				logger.info(homeanc);
				driver.navigate().to(homeanc);
				getSmartt();
			}
		}
		
	}

	public String validateSamrtt(String brnds)  {
		String stresult = null;
		logger.info("Validating Smartt "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
		
	}
	
	public String updateComments() {
		String Comments = comment.toString();
		return Comments;
	}
	
	public WebElement smarttFrame() {
		
		WebElement iframe;
		try {
			iframe = driver.findElement(By.xpath("//iframe[@id='ford-service-iframe']"));
			logger.info("ford frame");
		} catch (Exception e) {
			try {
				iframe = driver.findElement(By.xpath("//iframe[@id='custom-iframe']"));
				logger.info("custom frame");
			} catch (Exception e1) {
				iframe = driver.findElement(By.xpath("//iframe[@id='fordServiceApptSchedulerIframe']"));
				logger.info("fordcdk frame");
			}
		}
		
		return iframe;
	}
	
	
	public WebElement getServiceMenu() {
		WebElement SP;
		try {
			SP = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'SERVICE')]"));
			logger.info("Service cap link");
		} catch (Exception e) {
			try {
				SP = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]"));
				logger.info("Service link");
			} catch (Exception e1) {
				try {
					SP = driver.findElement(By.xpath("//a[@title='Service']"));
					logger.info("Service title link");
				} catch (Exception e2) {
					logger.error("cant find service menu element "+e2.getClass().getName());
					return null;
				}
				
			}
		}
		return SP;
	}
	
	public void scheduleservice() {
		try {
			logger.info("--------Service appointment from Homepage - Schedule service-------");	
			WebElement SP1 = getServiceMenu();
			mouseHover(SP1);
			WebElement SS1;
			try {
				SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]//following::a[contains(@href,'ServiceApp')]"));
			} catch (Exception e) {
				try {
					SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]//following::a[contains(@href,'schedule')]"));
				} catch (Exception e1) {
					
					try {
						SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'SERVICE')]//following::a[contains(.,'Schedule Service')]"));
					} catch (Exception e2) {
						SS1 = driver.findElement(By.xpath("//div[contains(@class,'menu')]//following::span[contains(text(),'Service')]//following::a[contains(text(),'Schedule Service')]"));
					}
				}
			}
			movetoelement(SS1);
			mouseHover(SS1);
			SS1.click();
			checkWindowHandle();
			getSmartt();
			/*int SSc = driver.findElements(By.partialLinkText("Schedule Service")).size();
			System.out.println("SSl count "+SSc);
			if(SSc>0) {
				System.out.println(driver.findElement(By.partialLinkText("Schedule Service")).getAttribute("innerHTML"));
				WebElement SS = driver.findElement(By.partialLinkText("Schedule Service"));
				SS.click();
				checkWindowHandle();
				getSmartt();
			}
			else {
				System.out.println("Schedule Service is not found");
				comment.append("Schedule Service from Menu - not validated\n");
			}*/
		} catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("Schedule Service from Menu - not validated\n");
		}
		
	}
	
	public void OARURL() {
		result = new StringBuilder();
		comment = new StringBuilder();		
		try {
			logger.info("------Validation of OAR from Service Menu-------");
			WebElement SP1 =  getServiceMenu();
			mouseHover(SP1);
			
			try {
				driver.findElement(By.xpath("//a[contains(text(),'Owner')]")).click();
				logger.info("Owner Advantage rewards Click Success - text");
			} catch (Exception e) {
				try {
					driver.findElement(By.xpath("//a[contains(@href,'owner')]")).click();
					logger.info("Owner Advantage rewards Click Success - href");
				} catch (Exception e1) {
					try {
						logger.info("Extracting URL and Navigating");
						String ourl = driver.findElement(By.xpath("//a[contains(text(),'Owner Advantage Rewards')]")).getAttribute("href");
						logger.info("Navigating to: "+ourl);
						driver.navigate().to(ourl);
					} catch (Exception e2) {
						logger.error("Not able to click on Owner Advantage Rewards");
						result.append("false");
						comment.append("Owner Advantage Rewards - Not Validated");
					}
					
				}
				
			}			
			
		}catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			OARURL();
		}
		catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("OAR - not validated\n");
		}
	}
	
	public String verifyOAR(String brnds) {
		logger.info("Verifying OAR URL");
		String oarurl = null;
		try {
			oarurl = driver.findElement(By.xpath("//a[contains(@href,'enroll')]")).getAttribute("href");
			logger.info("OAR URL is: "+oarurl);
			logger.info("From UDL is: "+OARURL);
			if(oarurl.toLowerCase().contains(OARURL.toLowerCase())) {
				result.append("true");
				logger.info("OAR URL equals to UDL");
			}
			else {
				result.append("false");
				logger.info("OAR URL not equal to UDL");
				comment.append("OAR URL Mismatch\n");
				comment.append("OAR from UDL: "+OARURL+" OARURL from site: "+oarurl+"\n");
			}
			
		}catch (Exception e) {
			logger.error("Cant Validate OAR URL "+e.getClass().getName());
			result.append("false");
			String enrollurl =null;
			try {
				enrollurl = driver.findElement(By.xpath("//a[contains(text(),'enroll')]")).getAttribute("href");
				if(enrollurl.contains("enroll")) {
					comment.append("OAR URL - not validated\n");
				}
				else {
					logger.info("Enroll button URL: "+enrollurl);
					comment.append("OAR URL Missing\n");
					
				}
			} catch (Exception e1) {
				logger.info("No Enroll button");
			}
		}
		
		String stresult = null;
		logger.info("Validating OAR "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
	}
	
	
	
	public void servicestndURL(String brnds) {
		stndURLservice(brnds);
		getSmartt();
		
	}

}
