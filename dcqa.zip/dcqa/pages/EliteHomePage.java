package dcqa.pages;

import org.apache.log4j.Logger;
import org.openqa.selenium.*;
import dcqa.utility.ExcelReadWrite;
import dcqa.functions.DCfunctions;
import java.util.List;


public class EliteHomePage extends DCfunctions {
	public StringBuilder result;
	public StringBuilder comment;
	ExcelReadWrite er = new ExcelReadWrite();
	
	final static Logger logger = Logger.getLogger(EliteHomePage.class); 
	 
	
	public void serviceandparts() throws Exception {
		try {
			result = new StringBuilder();
			comment = new StringBuilder();
			logger.info("-------Service appointment from Homepage - service department menu--------");		
			//Clicking on Service Menu from Homepage
			try {
				WebElement SP = getServiceMenu();
				try {
					driver.findElement(By.xpath("//ul[@data-dropdown-display-type='click']"));
					logger.info("Click Menu");
					SP.click();
				} catch (Exception e2) {
					try {
						driver.findElement(By.xpath("//ul[@data-dropdown-display-type='hover']"));
						logger.info("Hover Menu");
						mouseHover(SP);
					} catch (Exception e) {					
						mouseHover(SP);
						SP.click();	
						logger.info("Split Menu");
					}				
				}
					
				//Check whether it navigated to new page if not Click on Service department on the menu
				String currentURL = driver.getCurrentUrl();
				if(currentURL.toLowerCase().contains("service")) {
					//mouseHover(SP);
					logger.info("Navigated to another page on click of Menu");
				//<- on Service page look for Schedule service link->
					logger.info("Checking for Smartt Frame");
					checkSmartt();
					logger.info("Checking for Schedule service link in Page");
					WebElement SS1;
					try {
						SS1 = driver.findElement(By.linkText("Schedule Service"));
						logger.info("schedule service link present");
						movetoelement(SS1);
						SS1.click();
					} catch (Exception e) {
						try {
							SS1 = driver.findElement(By.xpath("//a[contains(text(),'Appointm')]"));
							logger.info("sch appointment link");
							movetoelement(SS1);
							SS1.click();
						} catch (Exception e1) {
							try {
								SS1 = driver.findElement(By.linkText("SCHEDULE SERVICE"));
								logger.info("sch capital link");
								movetoelement(SS1);
								SS1.click();
								
							} catch (Exception e2) {
								logger.error("Unable to click on Schedule service "+e2.getClass().getName());
							}
						}
						
					}
				}
				else {
					logger.info("Not Navigated to new page on click of Menu Clicking SubMenu");
					try {
						WebElement SS = SP.findElement(By.linkText("Service Center"));
						logger.info("service center linktext Present");
						SS.click();
						} catch (Exception e3) {
							try {
								WebElement SS = SP.findElement(By.xpath("//a[contains(.,'Center')][contains(@href,'service')]"));
								logger.info("serrvice Center link");
								SS.click();
							} catch (Exception e) {
								try {
									WebElement SS = SP.findElement(By.xpath("//a[contains(.,'Department')][contains(@href,'service')]"));
									logger.info("service department link");
									SS.click();
								} catch (Exception e1) {
									logger.error("Cant Click on Service Department "+e1.getClass().getName());
									SP.click();
								}
								
							}
							
						}
					logger.info("On the Page Checking for Smartt Frame");
					checkSmartt();
					logger.info("Check and Click on Schedule Service on Page");
					WebElement SS1;
					try {
						SS1 = driver.findElement(By.linkText("Schedule Service"));
						logger.info("schedule service link");
						//movetoelement(SS1);
						SS1.click();
					} catch (Exception e) {
						try {
							SS1 = driver.findElement(By.xpath("//a[contains(text(),'Appointm')]"));
							logger.info("sch appointment link");
							movetoelement(SS1);
							SS1.click();
						} catch (Exception e1) {
							try {
								SS1 = driver.findElement(By.xpath("//a[contains(@href,'service')]/img"));
								logger.info("sch img link");
								movetoelement(SS1);
								SS1.click();
							} catch (Exception e2) {
								logger.error("Unable to click on Schedule service "+e2.getClass().getName());
							}
							
						}
						
					}
				}
				checkWindowHandle();
				if(checkpage()<3) {
					
					getSmartt();	
				}
				else {
					logger.info("Page not loaded");	
					comment.append("Page not loaded\n");
					result.append("false");
				}
			
		} catch (Exception e2) {
			result.append("false");
			logger.error("Schedule service not validated in Service Department page "+e2.getClass().getName());	
			comment.append("Schedule service not validated in Service Department page\n");
			
		}
		}
		catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			serviceandparts();
		}
	}

	public void getSmartt() {
		logger.info("Getting Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			String smarttfrm = smarttframe.getAttribute("src");
			logger.info("->Smartt: "+smarttfrm);
			if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
				result.append("true");
				logger.info("Smartt Frame equals to UDL");
			}
			else {
				result.append("false");
				logger.info("Smartt Frame not equal to UDL");
				comment.append("Smartt Subset Changed from UDL\n");
			}
		} catch (Exception e) {
			logger.error("No Iframe Found");
			result.append("false");
			comment.append("Smartt Not installed\n");
		}
	}
	
	public void checkSmartt() {
		logger.info("Checking Iframe Value");
		try {
			WebElement smarttframe = smarttFrame();
			if(smarttframe!=null) {
				
				String smarttfrm = smarttframe.getAttribute("src");
				logger.info("->Smartt: "+smarttfrm);
				if(smarttfrm.toLowerCase().contains(smarttsub.toLowerCase())) {
					result.append("true");
					logger.info("Smartt Frame equals to UDL");
				}
				else {
					result.append("false");
					logger.info("Smartt Frame not equal to UDL");
					comment.append("Smartt Subset not equal to UDL\n");
				}
			} else {
				logger.error("No Smartt Frame in Page");
				
			}
		} catch (Exception e) {
			logger.info("No anothere frame in the Page");
		}
	}
	
	public void smartthome(String brnds) {
		try {
			logger.info("------Service appointment from Homepage-----");
			if (brnds.equals("1")) {
				driver.navigate().to(DealerURL);
			}
			if (brnds.equals("2")) {
				driver.navigate().to(LDealerURL);
			}
			if (brnds.equals("3")) {
				driver.navigate().to(DealerURL);
			}
			if (brnds.equals("4")) {
				driver.navigate().to(LDealerURL);
			}
		driver.navigate().refresh();
		String classe = null;
		String ctrl = null;
		int SP4 = driver.findElements(By.xpath("//div[contains(@class,'content')][contains(@class,'page')]")).size();
		logger.info("body class "+SP4);
		if(SP4>0) {
			List<WebElement> allOptions1 = driver.findElements(By.xpath("//div[contains(@class,'content')][contains(@class,'page')]"));			
			for(WebElement we1 : allOptions1) {
				logger.info(we1.getAttribute("class"));
				 classe = we1.getAttribute("class");
				 ctrl = "class";
			}
		}
		else {
			int SP41 = driver.findElements(By.xpath("//div[contains(@id,'content')][contains(@id,'page')]")).size();
			logger.info("body id "+SP4);
			if(SP41>0) {
				List<WebElement> allOptions1 = driver.findElements(By.xpath("//div[contains(@id,'content')][contains(@id,'page')]"));			
				for(WebElement we1 : allOptions1) {
					logger.info(we1.getAttribute("id"));
					 classe = we1.getAttribute("id");
					 ctrl = "id";
				}
			}
		}
		
		
		
		int SP3 = driver.findElements(By.xpath("//div[contains(@"+ctrl+",'"+classe+"')]//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]")).size();
		logger.info("Found SCH link "+SP3);
		if(SP3>0) {
			List<WebElement> allOptions = driver.findElements(By.xpath("//div[contains(@"+ctrl+",'"+classe+"')]//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]"));
			
			for(WebElement we : allOptions) {
				
				if(we.getAttribute("innerHTML").contains("slide")) {
					
				}else {					
					if(we.getText().toLowerCase().contains("schedule")) {
						logger.info("Schuedle Link: "+we.getAttribute("innerHTML"));
						int pty = we.getLocation().getY();
						pty=pty-200;
						((JavascriptExecutor)driver).executeScript("scroll(0,"+pty+")");
						we.click();
						break;
					}
					if(we.getText().toLowerCase().contains("service")) {
						logger.info("Service Link: "+we.getAttribute("innerHTML"));
						int pty = we.getLocation().getY();
						pty=pty-200;
						((JavascriptExecutor)driver).executeScript("scroll(0,"+pty+")");
						we.click();
						break;
					}
					
				}
				if(we.getAttribute("innerHTML").contains("img")) {	
					logger.info("img :"+we.getAttribute("innerHTML"));
					try {
						we = driver.findElement(By.xpath("//div[contains(@class,'"+classe+"')]//following::a[contains(@href,'service')][not(contains(@href,'coupons'))]/img"));
							int pty = we.getLocation().getY();
							pty=pty-200;
							((JavascriptExecutor)driver).executeScript("scroll(0,"+pty+")");
							we.click();
							break;
					} catch (Exception e) {
						logger.error("cant click on image "+e.getClass().getName());
					}				
				}
				
			}
			WebElement SS1;
			logger.info("Looking for Frame in Page");
			checkSmartt();
			logger.info("Check and Click on Schedule service link");
			try {
				SS1 = driver.findElement(By.linkText("Schedule Service"));
				logger.info("schedule link");
				SS1.click();
			} catch (Exception e) {
				try {
					SS1 = driver.findElement(By.xpath("//a[contains(text(),'Appointm')]"));
					logger.info("sch appointment link");
					SS1.click();
				} catch (Exception e1) {
					try {
						SS1 = driver.findElement(By.linkText("SCHEDULE SERVICE"));
						logger.info("SCH cap link");
						SS1.click();
						
					} catch (Exception e2) {
						logger.error("Unable to click on Schedule service "+e2.getClass().getName());
					}
				}
				
			}
			checkWindowHandle();
			if(checkpage()<3) {
				getSmartt();	
			}
			else {
				logger.info("Page not loaded");	
				comment.append("Page not loaded\n");
				result.append("false");
			}
			
		}
		}
		catch (TimeoutException e){
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			smartthome(brnds);
		}
		
		
	}

	public String validateSamrtt(String brnds)  {
		String stresult = null;
		logger.info("Validating Smartt "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
		
	}
	
	public String updateComments() {
		String Comments = comment.toString();
		return Comments;
	}
	public WebElement smarttFrame() {
		checkRuntimeError();
		WebElement iframe = null;
		try {
			iframe = driver.findElement(By.xpath("//iframe[@id='ford-service-iframe']"));
			logger.info("ford frame");
		} catch (Exception e) {
			try {
				iframe = driver.findElement(By.xpath("//iframe[@id='custom-iframe']"));
				logger.info("custom frame");
			} catch (Exception e1) {
				try {
					iframe = driver.findElement(By.xpath("//iframe[@id='fordServiceApptSchedulerIframe']"));
					logger.info("smartt Iframe");
				} catch (Exception e2) {
					try {
						iframe = driver.findElement(By.xpath("//iframe[contains(@src,'NAKEDLIME')]"));
						logger.info("Reynolds Iframe");
						
					} catch (Exception e3) {
						try {
							iframe = driver.findElement(By.xpath("//iframe[contains(@src,'cid')]"));
							logger.info("CDK Iframe");
						} catch (Exception e4) {
							try {
								iframe = driver.findElement(By.xpath("//iframe[contains(@id,'frame')][@scrolling='yes']"));
								logger.info("randomid Iframe");
							} catch (Exception e5) {
								iframe = driver.findElement(By.xpath("//iframe[contains(@src,'nakedlime')]"));
								logger.info("Reynolds Iframe");
							}
							
						}
					}
				}
				
			}
			
		}
		
		return iframe;
	}

	public void checkRuntimeError() {
		try {
			int se = driver.findElements(By.xpath("//h1[contains(text(),'Server Error')]")).size();
			if(se>0) {
				driver.manage().deleteAllCookies();
				driver.navigate().refresh();
			}
			
		} catch (Exception e) {
			
		}
	}
	
	
	public WebElement getServiceMenu() {
		WebElement SP;
		try {
			SP = driver.findElement(By.xpath("//nav[@class='lg-nav']//following::a[contains(text(),'Service')]"));
			logger.info("Service Menu with lg-nav Class");
		} catch (Exception e) {
			try {
				SP = driver.findElement(By.xpath("//div[@class='ddc-content buttonblock-default pull-left navigation-buttons']//a/span[contains(text(),'Service')]/span[contains(text(),'Center')]"));
				//SP = driver.findElement(By.xpath("//div[@class='ddc-content buttonblock-default pull-left navigation-buttons']//a[@class='service']/span[contains(text(),'Service')]"));
				logger.info("Service Center Button");
			} catch (Exception e1) {				
				try {
					try {
						SP = driver.findElement(By.xpath("//a[text(),'Service & Parts']"));
					} catch (Exception e3) {
						SP = driver.findElement(By.xpath("//a[@class='nav-with-children'][contains(text(),'Service')]"));
					}
					logger.info("Service & Parts Menu");
				} catch (Exception e2) {
					
					try {
						SP = driver.findElement(By.xpath("//a[contains(text(),'Service')][contains(.,'Vehicle')]"));
						logger.info("Service Your Vehicle Menu");
					} catch (Exception e3) {
						try {
							try {
								SP = driver.findElement(By.xpath("//a[contains(text(),'Service')][contains(.,'Parts')]"));
							} catch (Exception e4) {
								SP = driver.findElement(By.xpath("//span[contains(text(),'Service')][contains(.,'Parts')]"));
							}
							logger.info("Service Parts Menu as Split");
						} catch (Exception e4) {
							try {
								SP = driver.findElement(By.xpath("//a[contains(text(),'Service')]"));
								logger.info("General Service Menu");
							} catch (Exception e5) {
								logger.error("cant find service menu element "+e5.getClass().getName());
								return null;
							}
							
						}
						
					}
					
				}
			}
		}
		return SP;
	}
	
	public WebElement getServiceParts() {
		WebElement SP;
		try {
			SP = driver.findElement(By.xpath("//nav[@class='lg-nav']//following::a[contains(text(),'Service')]"));
			logger.info("Service Menu with lg-nav Class");
		} catch (Exception e) {
			try {
				try {
					SP = driver.findElement(By.xpath("//a[text(),'Service & Parts']"));
				} catch (Exception e1) {
					SP = driver.findElement(By.xpath("//a[@class='nav-with-children'][contains(text(),'Service')]"));
				}
				logger.info("Service&Parts Menu");
			} catch (Exception e1) {								
					try {
						SP = driver.findElement(By.xpath("//a[contains(text(),'Service')][contains(.,'Vehicle')]"));						
						logger.info("Service Your Vehicle Menu");
					} catch (Exception e3) {
						try {
							SP = driver.findElement(By.xpath("//a[contains(text(),'Service')][contains(.,'Parts')]"));
							logger.info("Service Parts Menu as Split");
						} catch (Exception e2) {
							try {
								SP = driver.findElement(By.xpath("//span[contains(text(),'Service')][contains(.,'Parts')]"));
								logger.info("Service Parts Menu in Span");
							} catch (Exception e4) {
								logger.error("cant find service menu element "+e4.getClass().getName());
								return null;
							}
							
						}
						
					}
					
				}
			
		}
		return SP;
	}
	public void scheduleservice() {
		try {
			logger.info("------Service appointment from Homepage - Schedule service-------");
			//launchDealer();
			WebElement SP1 = getServiceParts();
			try {
				driver.findElement(By.xpath("//ul[@data-dropdown-display-type='click']"));
				logger.info("Click Menu");
				SP1.click();
			} catch (Exception e2) {
				try {
					driver.findElement(By.xpath("//ul[@data-dropdown-display-type='hover']"));
					logger.info("Hover Menu");
					mouseHover(SP1);
				} catch (Exception e) {
					logger.info("Split Menu");
					mouseHover(SP1);
					SP1.click();
					//mouseHover(SP1);
				}				
			}
			String currentURL = driver.getCurrentUrl();
			if(currentURL.toLowerCase().contains("service")) {
				logger.info("Navigated to new page");
				SP1 = getServiceParts();
				mouseHover(SP1);
				
				int SSc = SP1.findElements(By.xpath("//a[contains(text(),'Schedule')][contains(.,'Service')]")).size();
				logger.info("Schedule service link count "+SSc);
				if(SSc>0) {
					logger.info("Checking for schedule service link");
					try {
						driver.findElement(By.linkText("Schedule Service")).click();
						logger.info("Schedule service link");
					} catch (Exception e) {
						try {
							driver.findElement(By.xpath("//a[contains(text(),'Schedule')][contains(.,'Service')]")).click();
							logger.info("Schedule & service link");
						} catch (Exception e1) {
							driver.manage().deleteAllCookies();
							driver.findElement(By.xpath("//a[contains(text(),'Appointment')][contains(.,'Service')]")).click();
							logger.info("Service appointment link");
						}
					}	
					checkWindowHandle();
					if(checkpage()<3) {
						getSmartt();	
					}
					else {
						logger.info("Page not loaded");	
						comment.append("Page not loaded\n");
						result.append("false");
					}
				}
				else {
					logger.error("Schedule Service is not found");
					comment.append("Schedule Service from Menu - not validated\n");
					/*mouseHover(SP1);
					SP1.click();
					mouseHover(SP1);*/
					int SSa = driver.findElements(By.xpath("//a[contains(.,'Appointment')][contains(.,'Service')]")).size();
					logger.info("SS appointment count "+SSa);
					if(SSa>0) {
						try {
							driver.findElement(By.linkText("Schedule Service")).click();
						} catch (Exception e) {
							driver.manage().deleteAllCookies();
							driver.findElement(By.xpath("//a[contains(.,'Appointment')][contains(.,'Service')]")).click();
							
						}	
						checkWindowHandle();
						if(checkpage()<3) {
							getSmartt();	
						}
						else {
							logger.info("Page not loaded");	
							comment.append("Page not loaded\n");
							result.append("false");
						}
					}
					else {
						logger.info("Service Appointment is not found");
						comment.append("Service Appointment from Menu - not validated\n");
					}
				}
				
				
			}
			else {
				int SSc = driver.findElements(By.linkText("Schedule Service")).size();
				logger.info("Schedule service link count "+SSc);
				if(SSc>0) {
					driver.findElement(By.linkText("Schedule Service")).click();	
					checkWindowHandle();
					if(checkpage()<3) {
						getSmartt();	
					}
					else {
						logger.info("Page not loaded");	
						comment.append("Page not loaded\n");
						result.append("false");
					}
				}
				else {
					logger.info("Schedule Service is not found");
					comment.append("Schedule Service from Menu - not validated\n");
				}
			}
		} catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			scheduleservice();
		}
		catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("Schedule Service from Menu - not validated\n");
		}
		
	}
	
	
	public void OARURL() {
		result = new StringBuilder();
		comment = new StringBuilder();
		
		try {
			logger.info("------Validation of OAR from Service Menu-------");
			WebElement SP1 = getServiceParts();
			try {
				driver.findElement(By.xpath("//ul[@data-dropdown-display-type='click']"));
				logger.info("Click Menu");
				SP1.click();
			} catch (Exception e2) {
				try {
					driver.findElement(By.xpath("//ul[@data-dropdown-display-type='hover']"));
					logger.info("Hover Menu");
					mouseHover(SP1);
				} catch (Exception e) {
					logger.info("Split Menu");
					mouseHover(SP1);
					SP1.click();
					//mouseHover(SP1);
				}				
			}
			try {
				driver.findElement(By.xpath("//a[contains(text(),'Owner')]")).click();
				logger.info("Owner Advantage rewards Click Success - text");
			} catch (Exception e) {
				try {
					driver.findElement(By.xpath("//a[contains(@href,'owner')]")).click();
					logger.info("Owner Advantage rewards Click Success - href");
				} catch (Exception e1) {
					try {
						logger.info("Extracting URL and Navigating");
						String ourl = driver.findElement(By.xpath("//a[contains(text(),'Owner Advantage Rewards')]")).getAttribute("href");
						logger.info("Navigating to: "+ourl);
						driver.navigate().to(ourl);
					} catch (Exception e2) {
						logger.error("Not able to click on Owner Advantage Rewards");
						result.append("false");
						comment.append("Owner Advantage Rewards - Not Validated");
					}
					
				}
				
			}			
			
		}catch(TimeoutException e) {
			logger.info("Timeout exception");
			driver.manage().deleteAllCookies();
			driver.navigate().refresh();
			OARURL();
		}
		catch (Exception e) {
			logger.error("Cant find Service Menu "+e.getClass().getName());
			comment.append("OAR - not validated\n");
		}
	}
	
	public String verifyOAR(String brnds) {
		logger.info("Verifying OAR URL");
		String oarurl = null;
		try {
			oarurl = driver.findElement(By.xpath("//a[contains(@href,'enroll')]")).getAttribute("href");
			logger.info("OAR URL is: "+oarurl);
			logger.info("From UDL is: "+OARURL);
			if(oarurl.toLowerCase().contains(OARURL.toLowerCase())) {
				result.append("true");
				logger.info("OAR URL equals to UDL");
			}
			else {
				result.append("false");
				logger.info("OAR URL not equal to UDL");
				comment.append("OAR URL Mismatch\n");
				comment.append("OAR from UDL: "+OARURL+" OARURL from site: "+oarurl+"\n");
			}
			
		}catch (Exception e) {
			logger.error("Cant Validate OAR URL "+e.getClass().getName());
			result.append("false");
			String enrollurl =null;
			try {
				enrollurl = driver.findElement(By.xpath("//a[contains(text(),'enroll')]")).getAttribute("href");
				if(enrollurl.contains("enroll")) {
					comment.append("OAR URL - not validated\n");
				}
				else {
					logger.info("Enroll button URL: "+enrollurl);
					comment.append("OAR URL Missing\n");
					
				}
			} catch (Exception e1) {
				logger.info("No Enroll button");
			}
		}
		
		String stresult = null;
		logger.info("Validating OAR "+ result);
		if (brnds.equals("1")) {
		if (result.toString().contains("false")) {
			logger.info("Fail Ford");
			stresult = "Fail Ford";
			
		}
		else {
			logger.info("Pass Ford");
			stresult = "Pass Ford";
			
		}
		}
		if (brnds.equals("2")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		if (brnds.equals("3")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Ford");
				stresult = "Fail Ford";
				
			}
			else {
				logger.info("Pass Ford");
				stresult = "Pass Ford";
				
			}
			}
		if (brnds.equals("4")) {
			if (result.toString().contains("false")) {
				logger.info("Fail Lincoln");
				stresult = "Fail Lincoln";
				
			}
			else {
				logger.info("Pass Lincoln");
				stresult = "Pass Lincoln";
				
			}
			}
		return stresult;
	}
	
	
	
	public void servicestndURL(String brnds) {
		
		stndURLservice(brnds);
		if(checkpage()<3) {
			getSmartt();	
		}
		else {
			logger.info("Page not loaded");	
			comment.append("Page not loaded\n");
			result.append("false");
		}
		
	}

}
