package dcqa.pages;


import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import dcqa.functions.DCfunctions;
import dcqa.utility.ExcelReadWrite;
import net.lightbody.bmp.BrowserMobProxy;



public class TagScenario {
	
	ExcelReadWrite er = new ExcelReadWrite();
	ExcelReadWrite pver = new ExcelReadWrite();
	DCfunctions dcf = new DCfunctions();
	
	public int pvrow,pvclm,scenario=1;
	public String Scename,dlurl,frameurl;
	public WebDriver driver,mdriver;
	public BrowserMobProxy proxy,mproxy;
	String USR_DIR = System.getProperty("user.dir");
	public int sectrow;
	final static Logger logger = Logger.getLogger(TagScenario.class);
	
	public void Proxysetup() throws Exception {
		driver = dcf.launchChromeproxy();
		proxy = dcf.proxy;
	}
	
	
	public void DOPagescen(String Rprtfile, int scenrow, int secrow) throws Throwable {
		er.ExcelRead(USR_DIR+"/src/main/java/pvdocs/DealerOn-PagesVariables-180809.xlsx");
		pver.ExcelRead(Rprtfile);
		pvclm = er.getColumnCount("PAGES VARIABLES");
		pvrow = pver.getRowCount("Sheet1");
		frameurl = null;
		String scen = null;
		dlurl=null;
		sectrow = secrow;
		outerloop:
		for(scenario=scenrow;scenario<pvrow;scenario++) {
			Scename = pver.getCellData("Sheet1", scenario, 1);
			dlurl= DCfunctions.DealerURL;
			if(Scename.contains("Section")) {
				logger.info("Executing Scenario: "+Scename);
				String[] section = Scename.split(":");
				switch(section[1].trim()) {
				
				/** Executing the test scripts under
				 * Global Actions Section 
				 * Maran
				 * **/
				
				case "Global Actions":
					int glbend = 6;
					for(int scena=sectrow;scena<glbend;scena++) {
						scen = pver.getCellData("Sheet1", scena, 1);
						
						System.out.println("----->"+scen);
						
						String[] tgscen = scen.split(":");
						System.out.println(tgscen[2]);
						switch(tgscen[2]) {
						case "sitemap":
							System.out.println("inside sitemap "+DCfunctions.sitelinks.size());
							for(String link : DCfunctions.sitelinks) {
								
								if(link.contains(tgscen[2])) {	
									frameurl = link;
								}
							}
							logger.info("Navigating to link: "+frameurl);
							proxy.newHar();
							driver.navigate().to(frameurl);
							scenario=1;
							sectrow++;
							break outerloop;
						case "privacy":
							for(String link : DCfunctions.sitelinks) {
								if(link.contains(tgscen[2])) {
									frameurl = link;
								}
							}
							logger.info("Navigating to link: "+frameurl);
							proxy.newHar();
							driver.navigate().to(frameurl);
							scenario=1;
							sectrow++;
							break outerloop;
						
						case "disclosures":
							for(String link : DCfunctions.sitelinks) {
								if(link.contains("disclosure")) {
									frameurl = link;
								}
							}
							logger.info("Navigating to link: "+frameurl);
							proxy.newHar();
							driver.navigate().to(frameurl);
							scenario=1;
							sectrow++;
							break outerloop;
						
						default:
							logger.info("Action: "+scen);
							proxy.endHar();
							sectrow++;
							
						}
					}
					scenario=glbend;
					sectrow++;
				break outerloop;

				/** Executing the test scripts under
				 * HomePage Section 
				 * Maran
				 * **/
				
				case "Homepage":
					int hmend = 9;
					logger.info("In Homepage");
					for(int scena=sectrow;scena<hmend;) {
						scen = pver.getCellData("Sheet1", scena, 1);
						System.out.println("----->"+scen);
						
						String[] tgscen = scen.split(":");
						if(tgscen.length>2) {
							logger.info("Performing action: "+tgscen[2]);
							proxy.newHar();
							driver.findElement(By.xpath("//a[contains(@data-slide,'prev')]")).click();
							scenario=hmend-1;
							sectrow++;
							break outerloop;
						}else {
							logger.info("Navigating to Homepage");
							proxy.newHar();
							driver.navigate().to(dlurl);
							//scenario=hmend-1;
							sectrow++;
						break outerloop;
						}
						
						
					}					
				break;	
				case "Custom":
					logger.info("In Custom page");
					
					scen = pver.getCellData("Sheet1", 10, 1);
					logger.info("on 6th row: "+scen);
					proxy.endHar();
					sectrow++;
					scenario=10;
				break outerloop;
				case "Vehicle Search Inventory -new":
					frameurl = dlurl+"/new-inventory/";
					System.out.println(frameurl);
					System.exit(1);
					for(scenario=12;scenario<25;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=24;
				break;
				case "Vehicle Search Inventory -used":
					frameurl = dlurl+"/used-inventory/";
					System.out.println(frameurl);
					for(scenario=26;scenario<39;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=38;
				break;
				case "Vehicle Search Inventory -other":
					frameurl = dlurl+"/new-inventory/";
					System.out.println(frameurl);
					for(scenario=40;scenario<53;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=52;
				break;
				case "Vehicle Details - new":
					frameurl = dlurl+"/new-inventory/";
					System.out.println(frameurl);
					for(scenario=54;scenario<73;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=72;
				break;
				case "Vehicle Details - used":
					frameurl = dlurl+"/used-inventory/";
					System.out.println(frameurl);
					for(scenario=74;scenario<93;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=92;
				break;
				case "Vehicle Details - other":
					frameurl = dlurl+"/new-inventory/";
					System.out.println(frameurl);
					for(scenario=94;scenario<113;scenario++) {
						scen = pver.getCellData("Sheet1", scenario, 1);
						System.out.println("----->"+scen);
						
						
					}
					scenario=112;
				break;
				
				default:
					System.out.println("On main default section");
					
				}
				//System.exit(1);
			}
	/*		else {
				logger.info("Collecting metrics for Sceanrio-> "+Scename);
				
				String[] tgscenario = Scename.split(":");
				System.out.println("Page: "+tgscenario[1]);
				System.out.println("Page Category: "+tgscenario[2]);
				logger.info("Forming links");
				
				switch(tgscenario[2]) {
				case "si":
					if(tgscenario[1].equalsIgnoreCase("new")) {
						frameurl = dlurl+"/new-inventory/";
						System.out.println(frameurl);
					}
				break;
				case "":
					
				}
				for(String link : DCfunctions.sitelinks) {
					if(link.contains(tgscenario[2])) {
						System.out.println("Navigating to link: "+link);
					}else {
						if(tgscenario.length>3 ) {
							System.out.println("length is more -3");
							if(tgscenario[3]!=null) {
								System.out.println("End Page: "+tgscenario[3]);
							}
							
							if(tgscenario.length>=4 ) {
								if(tgscenario[4]!=null) {
									if(!tgscenario[4].contains("<")) {
										System.out.println("Action: "+tgscenario[4]);
									}else {
										System.out.println("Vehicle name: "+tgscenario[4]);
									}
								}
							}
							if(tgscenario.length>=5 ) {
								if(tgscenario[5]!=null && !tgscenario[5].contains("<")) {										
										System.out.println("Thank you page: "+tgscenario[5]);
																		
								}
							}
							if(tgscenario.length>=6 ) {
								if(tgscenario[6]!=null ) {										
										System.out.println("Vehicle name: "+tgscenario[6]);										
								}
							}
								
							}
						}
						
				}
				
					
				}*/
				//System.exit(1);
			}
			
		}
	

}
