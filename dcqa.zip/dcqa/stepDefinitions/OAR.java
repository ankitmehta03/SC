package dcqa.stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;

import cucumber.api.java.en.Then;
import dcqa.functions.DCfunctions;
import dcqa.pages.BaseHomePage;
import dcqa.pages.CDKHomePage;
import dcqa.pages.DDCHomePage;
import dcqa.pages.DOHomePage;
import dcqa.pages.EliteHomePage;
import dcqa.pages.JazelHomePage;
import dcqa.utility.ExcelReadWrite;

public class OAR {
	
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}	
	DOHomePage dohme = new DOHomePage();
	CDKHomePage cdkhme = new CDKHomePage();
	JazelHomePage jzlhme = new JazelHomePage();
	DDCHomePage ddchme = new DDCHomePage();
	EliteHomePage Elithme = new EliteHomePage();
	BaseHomePage basehme = new BaseHomePage();
	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	public String pacode,paparsed,platform,brand,dlurl,Oarurl;
	public int rowl=0,col,count,clm =444;
	public String PAcode;
	public Boolean flag = false;
	final static Logger logger = Logger.getLogger(OAR.class);

	@Then("^Read PA code from Excel$")
	public void read_PA_code_from_Excel() throws Throwable {
		dcf.readExcel("OAR.xlsx");
		count=dcf.rowcnt;
		logger.info("Total PACode to execute: "+count);
	}

	@Then("^Parse UDL and get parameters required$")
	public void parse_UDL_and_get_parameters_required() throws Throwable {
		if(clm<count) {	
			brand=null;
			PAcode = dcf.getExcelData("Ford", clm, 0); 
			logger.info("\nPACode to Validate: "+PAcode+" From row: "+(clm+1));
			pacode = dcf.parsepacode(PAcode);
			dcf.parsUDL(pacode, clm);
			brand = dcf.brnd;
			dlurl = DCfunctions.DealerURL;
			Oarurl = DCfunctions.OARURL;
			logger.info("OAR URL for PACode is: "+Oarurl);
			if(dlurl==null){
				logger.info("PA code "+pacode+" returned null results from UDL");
				clm++;
				parse_UDL_and_get_parameters_required();
			}else {
				if(brand.equals("3")) {
					flag=true;
					
				}
				
				launch_Dealersite_URL_from_UDL();
			}
			
		}
	}

	@Then("^Launch Dealersite URL from UDL$")
	public void launch_Dealersite_URL_from_UDL() throws Throwable {
		if(clm<count) {
			dcf.launchDealer(brand);
			if(dcf.sitecheck.equals("true")) {
				identify_Dealer_Platform();
			}
			else {
				clm++;
				parse_UDL_and_get_parameters_required();
			}
			
		}
	}

	@Then("^Identify Dealer Platform$")
	public void identify_Dealer_Platform() throws Throwable {
		if(clm<count) {
			platform = null;
			if(brand.equals("4")||(brand.equals("2"))) {
				rowl++;
				platform = dcf.identifyPlatform(clm);
				//platform = dcf.lpltfm;
				if(platform.equals(null)) {
					platform = dcf.lpltfm;
				}				
				dcf.setExcelData("Lincoln", clm, 2, platform);
				navigate_to_Owner_Advantage_Rewards_page_with(platform);
			}
			
			else {
				platform = dcf.identifyPlatform(clm);
				navigate_to_Owner_Advantage_Rewards_page_with(platform);
			}
			
			
		}
	}

	@Then("^Navigate to Owner Advantage Rewards page with \"([^\"]*)\"$")
	public void navigate_to_Owner_Advantage_Rewards_page_with(String pfm) throws Throwable {
		if(clm<count) {
			logger.info("After sending value: "+pfm);
			   
			switch (pfm) {
			case "DO":
				dohme.OARURL();
				break;
			case "CDK":
				cdkhme.OARURL();
				break;
			case "Elite":
				Elithme.OARURL();
				break;
			case "DDC":
				ddchme.OARURL();
				break;
			case "Jazel":
				jzlhme.OARURL();
				break;
			case "Base":
				basehme.OARURL();
				break;
			default:
				logger.info(pfm+" is not scripted");
			
			}
			verify_OAR_URL(platform);
		}
	    
	}

	@Then("^Verify OAR URL \"([^\"]*)\"$")
	public void verify_OAR_URL(String pfm) throws Throwable {
		String Smarttresult = null;
		String comments = null;
		if(clm<count) {
			   
			switch (pfm) {
			case "DO":
				Smarttresult = dohme.verifyOAR(brand);
				comments = dohme.updateComments();
				break;
			case "CDK":
				Smarttresult = cdkhme.verifyOAR(brand);
				comments = cdkhme.updateComments();
				break;
			case "Elite":
				Smarttresult = Elithme.verifyOAR(brand);
				comments = Elithme.updateComments();
				break;
			case "DDC":
				Smarttresult = ddchme.verifyOAR(brand);
				comments = ddchme.updateComments();
				break;
			case "Jazel":
				Smarttresult = jzlhme.verifyOAR(brand);
				comments = jzlhme.updateComments();
				break;
			case "Base":
				Smarttresult = basehme.verifyOAR(brand);
				comments = basehme.updateComments();
				break;
			default:
				logger.info(pfm+" is not scripted");
			
			}
			if(Smarttresult!=null) {
				if(Smarttresult.contains("Ford")) {
					logger.info("Writing Ford results");
					dcf.setExcelData("Ford", clm, 4, Smarttresult);
					dcf.setExcelData("Ford", clm, 5, comments);
					
				}
				if(Smarttresult.contains("Lincoln")) {
					logger.info("Writing Lincoln results");
					dcf.setExcelData("Lincoln", clm, 4, Smarttresult);
					dcf.setExcelData("Lincoln", clm, 5, comments);
					
				}
				
			}
			
			if(flag) {
				brand="4";
				flag = false;
				launch_Dealersite_URL_from_UDL();
				
			}
			else {
				clm++;				
				parse_UDL_and_get_parameters_required();
			}
		}
	}



}
