package dcqa.stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import dcqa.utility.ExcelReadWrite;
import dcqa.functions.DCfunctions;
import dcqa.pages.*;




public class Smartt {
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}	
	DOHomePage dohme = new DOHomePage();
	CDKHomePage cdkhme = new CDKHomePage();
	JazelHomePage jzlhme = new JazelHomePage();
	DDCHomePage ddchme = new DDCHomePage();
	EliteHomePage Elithme = new EliteHomePage();
	BaseHomePage basehme = new BaseHomePage();
	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	public String pacode,paparsed,platform,brand,dlurl;
	public int rowl=0,col,count,clm =1;
	public String PAcode;
	public Boolean flag = false;
	final static Logger logger = Logger.getLogger(Smartt.class);
	
	
		
	@Given("^User Launch Chrome$")
	public void user_Launch_Chrome() throws Throwable {
		dcf.launchChrome();
		logger.info("Chrome Launched");
	   
	}

	@Then("^Read data PA code from Excel file$")
	public void read_data_PA_code_from_Excel_file() throws Throwable {
		
		dcf.readExcel("Smartt.xlsx");
		count=dcf.rowcnt;
		logger.info("Total PACode to execute: "+count);		
	}
	
		
	@Then("^Parse the UDL Param$")
	public void parse_the_UDL_Param() throws Throwable {
		if(clm<count) {	
			brand=null;
			PAcode = dcf.getExcelData("Ford", clm, 0); 
			logger.info("\nPACode to Validate: "+PAcode+" From row: "+(clm+1));
			pacode = dcf.parsepacode(PAcode);
			dcf.parsUDL(pacode, clm);
			brand = dcf.brnd;
			dlurl = DCfunctions.DealerURL;
			if(dlurl==null){
				logger.info("PA code "+pacode+" returned null results from UDL");
				clm++;
				parse_the_UDL_Param();
			}else {
				if(brand.equals("3")) {
					flag=true;
					
				}
				
				launch_Dealer_site();
			}
			
		}
	   
	}

	@Given("^Launch Dealer site$")
	public void launch_Dealer_site() throws Throwable {
		if(clm<count) {
			dcf.launchDealer(brand);
			if(dcf.sitecheck.equals("true")) {
				identify_Platform();
			}else {
				logger.info("Null Dealer URL Skipping PAcode"+pacode);
				clm++;
				parse_the_UDL_Param();
			}
			
		}
	}

	@Then("^Identify Platform$")
	public void identify_Platform() throws Throwable {
		if(clm<count) {
			platform = null;
			if(brand.equals("4")||(brand.equals("2"))) {
				rowl++;
				platform = dcf.identifyPlatform(clm);
				//platform = dcf.lpltfm;
				if(platform.equals(null)) {
					platform = dcf.lpltfm;
				}				
				dcf.setExcelData("Lincoln", clm, 2, platform);
				navigate_to_Schedule_Service_from_Service_Department_menu_with(platform);
			}
			
			else {
				platform = dcf.identifyPlatform(clm);
				navigate_to_Schedule_Service_from_Service_Department_menu_with(platform);
			}
			
			
		}
	   
	   
	}

	@Then("^Navigate to Schedule Service from Service Department menu with \"([^\"]*)\"$")
	public void navigate_to_Schedule_Service_from_Service_Department_menu_with(String pfm) throws Throwable {
		if(clm<count) {
			logger.info("After sending value: "+pfm);
			   
			switch (pfm) {
			case "DO":
				dohme.serviceandparts();
				break;
			case "CDK":
				cdkhme.serviceandparts();
				break;
			case "Elite":
				Elithme.serviceandparts();
				break;
			case "DDC":
				ddchme.serviceandparts();
				break;
			case "Jazel":
				jzlhme.serviceandparts();
				break;
			case "Base":
				basehme.serviceandparts();
				break;
			default:
				logger.info(pfm+" is not scripted");
			
			}
		navigate_to_Schedule_Service_from_Service_and_parts_Menu_with(platform);
		}
	    
	}


	@And("^Validate Smartt form$")
	public void validate_Smartt_form() throws Throwable {
		String pfm = platform;
		String Smarttresult = null;
		String comments = null;
		if(clm<count) {
			switch (pfm) {
			case "DO":
				Smarttresult=dohme.validateSamrtt(brand);
				comments = dohme.updateComments();
				break;
			case "CDK":
				Smarttresult=cdkhme.validateSamrtt(brand);
				comments = cdkhme.updateComments();
				break;
			case "Elite":
				Smarttresult = Elithme.validateSamrtt(brand);
				comments = Elithme.updateComments();
				break;
			case "DDC":
				Smarttresult = ddchme.validateSamrtt(brand);
				comments = ddchme.updateComments();
				break;
			case "Jazel":
				Smarttresult = jzlhme.validateSamrtt(brand);
				comments = jzlhme.updateComments();
				break;
			case "Base":
				Smarttresult = basehme.validateSamrtt(brand);
				comments = basehme.updateComments();
				break;
			default:
				logger.info(pfm+" is not scripted");
			}
			if(Smarttresult!=null) {
				if(Smarttresult.contains("Ford")) {
					logger.info("Writing Ford results");
					dcf.setExcelData("Ford", clm, 4, Smarttresult);
					dcf.setExcelData("Ford", clm, 5, comments);
					
				}
				if(Smarttresult.contains("Lincoln")) {
					logger.info("Writing Lincoln results");
					dcf.setExcelData("Lincoln", clm, 4, Smarttresult);
					dcf.setExcelData("Lincoln", clm, 5, comments);
					
				}
				
			}
			
			if(flag) {
				brand="4";
				flag = false;
				launch_Dealer_site();
				
			}
			else {
				clm++;				
				parse_the_UDL_Param();
			}
			
		}
		
		dcf.close();
	    
	}

	@Then("^Navigate to Schedule Service from Service and parts Menu with \"([^\"]*)\"$")
	public void navigate_to_Schedule_Service_from_Service_and_parts_Menu_with(String pfm) throws Throwable {
		if(clm<count) {
			switch (pfm) {
			case "DO":
				dohme.scheduleservice();
				break;
			case "CDK":
				cdkhme.scheduleservice();
				break;
			case "Elite":
				Elithme.scheduleservice();
				break;
			case "DDC":
				ddchme.scheduleservice();
				break;
			case "Jazel":
				jzlhme.scheduleservice();
				break;
			case "Base":
				basehme.scheduleservice();
				break;
			default:
				logger.info(pfm+" is not scripted");
			}
		navigate_to_service_appointment_standard_URL_with(platform);
		}
	}
	
	
	@Then("^Get Smartt form value$")
	public void get_Smartt_form_value() throws Throwable {
		
	}
	
	
	@Then("^Navigate to service-appointment standard URL with \"([^\"]*)\"$")
	public void navigate_to_service_appointment_standard_URL_with(String pfm) throws Throwable {
		if(clm<count) {
			switch (pfm) {
			case "DO":
				dohme.servicestndURL(brand);
				break;
			case "CDK":
				cdkhme.servicestndURL(brand);
				break;
			case "Elite":
				Elithme.servicestndURL(brand);
				break;
			case "DDC":
				ddchme.servicestndURL(brand);
				break;
			case "Jazel":
				jzlhme.servicestndURL(brand);
				break;
			case "Base":
				basehme.servicestndURL(brand);
				break;
			default:
				logger.info(pfm+" is not scripted");
			}
	    
	    navigate_to_Schedule_service_from_Homepage_with(platform);
		}
	    
	}

	@Then("^Navigate to Schedule service from Homepage with \"([^\"]*)\"$")
	public void navigate_to_Schedule_service_from_Homepage_with(String pfm) throws Throwable {
		if(clm<count) {
			switch (pfm) {
			case "DO":
				dohme.smartthome(brand);
				break;
			case "CDK":
				cdkhme.smartthome(brand);
				break;
			case "Elite":
				Elithme.smartthome(brand);
				break;
			case "DDC":
				ddchme.smartthome(brand);
				break;
			case "Jazel":
				jzlhme.smartthome(brand);
				break;
			case "Base":
				basehme.smartthome(brand);
				break;
			default:
				logger.info(pfm+" is not scripted");
			}
		
		validate_Smartt_form();
		}
		
	}

}

