package dcqa.stepDefinitions;


import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import dcqa.functions.DCfunctions;
import dcqa.pages.BaseHomePage;
import dcqa.pages.CDKHomePage;
import dcqa.pages.DDCHomePage;
import dcqa.pages.DOHomePage;
import dcqa.pages.EliteHomePage;
import dcqa.pages.JazelHomePage;
import dcqa.utility.ExcelReadWrite;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.core.har.HarEntry;


public class Autoalert {
	
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}	
	DOHomePage dohme = new DOHomePage();
	CDKHomePage cdkhme = new CDKHomePage();
	JazelHomePage jzlhme = new JazelHomePage();
	DDCHomePage ddchme = new DDCHomePage();
	EliteHomePage Elithme = new EliteHomePage();
	BaseHomePage basehme = new BaseHomePage();
	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	public String pacode,paparsed,platform,device,dlurl;
	public int rowl=0,col,count,clm =1;
	public String PAcode;
	public Boolean flag = false;
	public WebDriver driver,mdriver;
	public BrowserMobProxy proxy,mproxy;
	String USR_DIR = System.getProperty("user.dir");
	final static Logger logger = Logger.getLogger(Autoalert.class);
	
	
	@Given("^Chrome browser launched$")
	public void chrome_browser_launched() throws Throwable {
		driver = dcf.launchChromeproxy();
		mdriver = dcf.launchmChromeproxy();
		proxy = dcf.proxy;
		mproxy = dcf.mproxy;
		
	}

	@Then("^Get PAcode from test data$")
	public void get_PAcode_from_test_data() throws Throwable {
	    dcf.readExcel("AutoAlert_0917.xlsx");
	    count=dcf.rowcnt;
	}

	@Then("^Parse data$")
	public void parse_data() throws Throwable {
	    if(clm<count) {
	    	logger.info("\nExecuting dealer "+clm+" Out of "+count);
	    	PAcode = dcf.getExcelData("Sheet1", clm, 0);
	    	pacode = dcf.parsepacode(PAcode);
	    	dcf.parsUDL(pacode, clm);
	    	dlurl = DCfunctions.DealerURL;
	    	dcf.setExcelData("Sheet1", clm, 1, dlurl);
	    	logger.info("Executing for: "+pacode+" Dealer URL: "+dlurl);
	    	device = "1";
	    	if(dlurl.length()>10) {
	    		open_Dealersite();
	    	}
	    	else {
	    		dcf.setExcelData("Sheet1", clm, 1, dlurl+" Not proper Dealer");
	    		clm++;
	    		parse_data();
	    	}
	    	
	    	
	    }
	}

	@Then("^Open Dealersite$")
	public void open_Dealersite() throws Throwable {
		if(clm<count) {	
			if(device.equals("1")) {
				proxy.newHar();
				logger.info("Clearing Cache");
				Runtime.getRuntime().exec(USR_DIR+"\\src\\main\\resources\\DClib\\clearcache.exe");	
				
				((JavascriptExecutor)driver).executeScript("window.open('about:blank','_blank');");
				dcf.checkWindowHandle();
				driver.get(dlurl);
				get_AutoAlert_tag_request();
			}
			if(device.equals("2")) {
				mproxy.newHar();
				mdriver.get(dlurl);
				get_AutoAlert_tag_request();
			}
			
		}	  
	  
	}

	@Then("^Get AutoAlert tag request$")
	public void get_AutoAlert_tag_request() throws Throwable {
		if(clm<count) {
			//String check = "Content - MotoFuze";
			logger.info("Looking for Tag content -- Content - MotoFuze");
			List<HarEntry> entries = proxy.getHar().getLog().getEntries();
			            for (HarEntry entry : entries) {
			            	if(entry.getRequest().getUrl().contains("wsassets.cobalt.com")) {
			            		logger.info("Request URL: "+entry.getRequest().getUrl());
			            		String pixeltag = entry.getResponse().getContent().getText();
			            		logger.info("Response text: "+entry.getResponse().getContent().getText());
			            		/*Matcher m = Pattern.compile("(Content)").matcher(pixeltag);
			            		while (m.find()){
			            		    String found = m.group();
			            		    System.out.println(found + " " + m.start() + " " +  m.end());
			            		    int end = m.end()+11;
				            		System.out.println(pixeltag.substring(m.start(), end));
			            		}*/
			            		
			            		if(pixeltag.toLowerCase().contains("MotoFuze".toLowerCase())) {
			            			logger.info("------->Tag Present<--------");
			            			flag = true;
			            		}
			            		else {			            			
			            			logger.info("<---no TAG-->");
			            			flag = false;
			            			
			            		}
			            	}
			            }
			   verify_tag();
		}
		
	}

	@Then("^Verify tag$")
	public void verify_tag() throws Throwable {		
		if(clm<count) {
			if(device.equals("1")) {
				if(flag) {
					dcf.setExcelData("Sheet1", clm, 2, "Pass");
				}
				else {
					dcf.setExcelData("Sheet1", clm, 2, "Fail");
				}
				device = "2";
				open_Dealersite();
			}
			if(device.equals("2")) {
				if(flag) {
					dcf.setExcelData("Sheet1", clm, 3, "Pass");
				}
				else {
					dcf.setExcelData("Sheet1", clm, 3, "Fail");
				}
			}
			clm++;
			 parse_data();
			
		}
	        
		   
	}


}
