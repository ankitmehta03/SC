package dcqa.stepDefinitions;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import dcqa.functions.DCfunctions;
import dcqa.pages.BaseHomePage;
import dcqa.pages.CDKHomePage;
import dcqa.pages.DDCHomePage;
import dcqa.pages.DOHomePage;
import dcqa.pages.EliteHomePage;
import dcqa.pages.JazelHomePage;
import dcqa.pages.TagScenario;
import dcqa.utility.ExcelReadWrite;
import net.lightbody.bmp.BrowserMobProxy;
import net.lightbody.bmp.core.har.HarEntry;
import net.lightbody.bmp.core.har.HarNameValuePair;

public class TagTest  {
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}		
	DOHomePage dohme = new DOHomePage();
	CDKHomePage cdkhme = new CDKHomePage();
	JazelHomePage jzlhme = new JazelHomePage();
	DDCHomePage ddchme = new DDCHomePage();
	EliteHomePage Elithme = new EliteHomePage();
	BaseHomePage basehme = new BaseHomePage();
	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	ExcelReadWrite pverd = new ExcelReadWrite();
	TagScenario Tgsc = new TagScenario();
	public String pacode,paparsed,platform,Scename,dlurl,brand;
	public int scenario,col,count,pvclm,pvrow,clm =1,scerow;
	public String PAcode,Rprtfile;
	public Boolean flag = false;
	public WebDriver driver,mdriver;
	public BrowserMobProxy proxy,mproxy;
	public String invpag[]= {"new","used","other"};
	Map<String, String> PVTag = new HashMap<String, String>();
	Map<Integer, String> Links = new HashMap<Integer, String>();
	HashSet<String> sitelinks = new HashSet<String>();
	String USR_DIR = System.getProperty("user.dir");
	final static Logger logger = Logger.getLogger(TagTest.class);
	
	
// Launch Chrome proxy browser
	@Given("^Launch Proxy browser$")
	public void launch_Proxy_browser() throws Throwable {
		Tgsc.Proxysetup();
	}

// Read Excel sheet which has PA code and Tag Report
	@Then("^Get Dealer PAcode from test data$")
	public void get_Dealer_PAcode_from_test_data() throws Throwable {
		 dcf.readExcel("Tag.xlsx");
		    count=dcf.rowcnt;
		  logger.info("No of Dealers to test: "+count); 
		  er.ExcelRead(USR_DIR+"/src/main/java/dcqa/testData/Tag Report.xlsx");
		  
		    
	}
	
// Create Tag report file with pa code and parse pacode with UDL to get dealer URL

	@Then("^Parse the Dealer data$")
	public void parse_the_Dealer_data() throws Throwable {
		  if(clm<count) {
			  PAcode = dcf.getExcelData("Ford", clm, 0);
		    	pacode = dcf.parsepacode(PAcode);
		    	Rprtfile = USR_DIR+"/src/main/java/pvReport/"+pacode+"_Tag Report.xlsx";
		    	File f = new File(Rprtfile);
		    	if(f.exists()) {
		    		logger.info("Report File Exists");
		    		//pver.ExcelRead(Rprtfile);
		    	} else {
		    		er.CopyBook(USR_DIR+"/src/main/java/dcqa/testData/Tag Report.xlsx", Rprtfile);
		    		//pver.ExcelRead(Rprtfile);
		    		logger.info("Creating "+pacode+" Tag Report file");
		    		//pver.getRowCount("Sheet1");
		    	}		    	
		    	dcf.parsUDL(pacode, clm);
		    	brand = dcf.brnd;
		    	dlurl = DCfunctions.DealerURL; // TODO check for brand code 3
		    	dcf.setExcelData("Ford", clm, 1, dlurl);
		    	if(dlurl.length()>10) {
		    		logger.info("Launching Dealer: "+dlurl);
		    		launch_Dealer_URL_from_parsed_data();
		    	}
		    	else {
		    		dcf.setExcelData("Ford", clm, 1, dlurl+" Not proper Dealer");
		    		clm++;
		    		parse_the_Dealer_data();
		    	}
		  }
	}
	
// launching the Dealer URL and creating har files

	@Then("^Launch Dealer URL from parsed data$")
	public void launch_Dealer_URL_from_parsed_data() throws Throwable {
		if(clm<count) {			
			Runtime.getRuntime().exec(USR_DIR+"/src/main/resources/DClib/clearcache.exe");				
			String dlrurl = null;
			//proxy.newHar();
			Tgsc.driver.get(dlurl);
			dlrurl = Tgsc.driver.getCurrentUrl();
			dcf.extractLinks(dlrurl,Tgsc.driver);
			
	        //read_the_tag_variables_from_excel();
	        get_the_platform_of_site();
		}
	}
	
	
	@Then("^get the platform of site$")
	public void get_the_platform_of_site() throws Throwable {
		if(clm<count) {	
			platform = null;
			if(brand.equals("4")||(brand.equals("2"))) {
				//rowl++;
				platform = dcf.identifyPlatform(clm);
				//platform = dcf.lpltfm;
				if(platform.equals(null)) {
					platform = dcf.lpltfm;
				}				
				dcf.setExcelData("Lincoln", clm, 2, platform);
				read_the_tag_variables_from_excel();
			}
			
			else {
				platform = dcf.identifyPlatform(clm);
				read_the_tag_variables_from_excel();
			}
		}
	}
	
	
	@Then("^Read the tag variables from excel$")
	public void read_the_tag_variables_from_excel() throws Throwable {
		if(clm<count) {	
			logger.info("Executing Scenarios for "+platform);
			pverd.ExcelRead(Rprtfile);
			//pvclm = er.getColumnCount("PAGES VARIABLES");
			pvrow = pverd.getRowCount("Sheet1");
			//logger.info("total Pv Columns: "+pvclm+" Total Scenarios : "+pvrow);
			scerow =2;
			logger.info("Total Scenarios : "+pvrow);
			
			switch(platform) {
			
			case "DO":
				for(scenario=1;scenario<pvrow;scenario++) {
					scenario = Tgsc.scenario;
					logger.info("***********Getting values for main: "+scenario+" row: "+scerow);
					Tgsc.DOPagescen(Rprtfile, scenario, scerow);
					get_the_Smetrics_call_from_site();
					scerow= Tgsc.sectrow;
				}
				
			break;
			
			default:
				logger.info("Platform "+platform+" is not scripted");
			}
			
							
			}
			System.exit(1);
			
		
	}
	
	

	@Then("^get the Smetrics call from site$")
	public void get_the_Smetrics_call_from_site() throws Throwable {
		if(clm<count) {
			/*proxy.newHar();
			driver.navigate().to(Tgsc.frameurl);*/
			//List<HarEntry> entries = proxy.getHar().getLog().getEntries();
			try {
				List<HarEntry> entries = Tgsc.proxy.getHar().getLog().getEntries();
				 for (HarEntry entry : entries) {
					if(entry.getRequest().getUrl().contains("smetrics.ford.com")) {
						if(entry.getRequest().getUrl().contains("fmcdealerconnection")) {
							//System.out.println("\n"+entry.getRequest().getMethod());
				    		System.out.println(entry.getRequest().getUrl());
				    		
				    		List<HarNameValuePair> pixeltag = entry.getRequest().getQueryString();
				    		PVTag = pixeltag.stream().collect(Collectors.toMap(HarNameValuePair::getName, HarNameValuePair::getValue));
				    		/*for(HarNameValuePair tag : pixeltag) {
				    			System.out.println(tag.getName()+""+tag.getValue());
				    				//System.out.println(tag);
				    				//System.out.println("------tag found");
				    			}*/
						}           			
					}
				}
			} catch (Exception e) {
				logger.info("There is no network logs");
				PVTag.clear();
			}
            verify_the_Page_variables(); 
		}
		  
	}

	@Then("^Verify the Page variables$")
	public void verify_the_Page_variables() throws Throwable {
	   if(clm<count) {
		   int secr = scerow+5;
		   logger.info("####### Checking the Page Varaibales from page against doc from row "+(secr)+" ###");
		   er.ExcelRead(USR_DIR+"/src/main/java/pvdocs/DealerOn-PagesVariables-180809.xlsx");
		   pvclm = er.getColumnCount("PAGES VARIABLES");		   
		   String pv = null;
			String pvvalue = null;
			String smvalue = null;
			String secpv =null;
			try {
				secpv = er.getCellData("PAGES VARIABLES", (secr), 1);
				if(secpv.contains("Section")) {
					 secr++;
					 scerow++;
					 logger.info("####### Checking the Page Varaibales from page against doc from row "+(secr)+" ###");
				 }else {
					 logger.info("Checking metrics for "+secpv);
				 }
			} catch (Exception e2) {
				
			}
			for(int k=8;k<pvclm;k++) {			
				 
				try {
					pvvalue = er.getCellData("PAGES VARIABLES", (secr), k);
				} catch (NullPointerException e1) {
					System.out.println("Null pointer at: "+k+" "+(secr));
				}
				
				if(pvvalue.length()>0) {
					pvvalue = pvvalue.replace("{ford|lincoln}", "ford");
					pvvalue = pvvalue.replace("{us|ca}", "us");
					pvvalue = pvvalue.replace("{eng|esp|fre}", "eng");
					pvvalue = pvvalue.replace("<prefix>", "dc");
					pvvalue = pvvalue.replace("<pc|tablet|mobile>", "pc");
					pv = er.getCellData("PAGES VARIABLES", 2, k);					
					logger.info("\nPage Varaible is: "+pv+" := "+pvvalue);
					try {
						smvalue = PVTag.get(pv).toString();
						logger.info("From smetrics tag map: "+pv+" := "+smvalue);
					} catch (NullPointerException e) {
						smvalue="";
						logger.info("From smetrics tag map: "+pv+" := null");
					}
					/*for(HarNameValuePair tag : pixeltag) {
						if(tag.getName().contains(pv)) {
							System.out.println("From smetrics tag: "+pv+" := "+tag.getValue());
						}
           			//System.out.println(tag.getName()+""+tag.getValue());
           				//System.out.println(tag);
           				//System.out.println("------tag found");
           			}*/
					//System.out.println("From smetrics tag map: "+pv+" := "+PVTag.get(pv).toString());
					
					if(pvvalue.contains("auto")||pvvalue.contains("<")||smvalue.contains("D=")) {
						pverd.setCellData("Sheet1", scerow, k-6, smvalue);						
					}else {
						if(smvalue.equalsIgnoreCase(pvvalue)) {
							pverd.setCellData("Sheet1", scerow, k-6, smvalue);
						}else {
							System.out.println("-----------didnt match------------");
							pverd.setCellData("Sheet1", scerow, k-6, smvalue);
							pverd.cellStyle("Sheet1",scerow, k-6);
							
							
						}
					}
					
				}
				
			}
		   System.out.println("completed");
		   /*System.exit(1);
		   clm++;*/
	   }
	}


}
