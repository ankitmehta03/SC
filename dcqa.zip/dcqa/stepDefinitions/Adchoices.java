package dcqa.stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebElement;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import dcqa.functions.DCfunctions;
import dcqa.utility.ExcelReadWrite;

public class Adchoices {
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}	
	
	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	public String pacode,paparsed,platform,brand,dlurl;
	public int rowl=0,col,count,clm =1;
	public String PAcode;
	public Boolean flag = false;
	final static Logger logger = Logger.getLogger(Adchoices.class);

	
	
	@Given("^Launch Chrome$")
	public void Launch_Chrome() throws Throwable {
		dcf.launchChrome();
		logger.info("Chrome Launched");
	   
	}

	@Then("^Read PA code from Excel file$")
	public void read_PA_code_from_Excel_file() throws Throwable {
		
		dcf.readExcel("AdChoices.xlsx");
		count=dcf.rowcnt;
		logger.info("Total PACode to execute: "+count);
		
		
		
		
	}
	
		
	@Then("^Parse UDL Parameters$")
	public void parse_UDL_Parameters() throws Throwable {
		if(clm<count) {	
			brand=null;
			PAcode = dcf.getExcelData("Ford", clm, 0); 
			logger.info("\nPACode to Validate: "+PAcode+" From row: "+(clm+1));
			pacode = dcf.parsepacode(PAcode);
			dcf.parsUDL(pacode, clm);
			brand = dcf.brnd;
			dlurl = DCfunctions.DealerURL;
			if((dlurl==null)&&(dlurl.length()>10)){
				logger.info("PA code "+pacode+" returned null results from UDL");
				clm++;
				parse_UDL_Parameters();
			}else {
				if(brand.equals("3")) {
					flag=true;
					
				}
				
				launch_Dealersite();
			}
			
		}
	   
	}

	@Given("^Launch Dealersite$")
	public void launch_Dealersite() throws Throwable {
		if(clm<count) {
			dcf.launchDealer(brand);
			if(dcf.sitecheck.equals("true")) {
				identify_Dealersite_Platform();
			}
			else {
				clm++;
				parse_UDL_Parameters();
			}
			
		}
	}

	@Then("^Identify Dealersite Platform$")
	public void identify_Dealersite_Platform() throws Throwable {
		if(clm<count) {
			platform = null;
			if(brand.equals("4")||(brand.equals("2"))) {
				rowl++;
				platform = dcf.identifyPlatform(clm);
				//platform = dcf.lpltfm;
				if(platform.equals(null)) {
					platform = dcf.lpltfm;
				}				
				dcf.setExcelData("Lincoln", clm, 2, platform);
				navigate_to_Adchoices_icon();
			}
			
			else {
				platform = dcf.identifyPlatform(clm);
				navigate_to_Adchoices_icon();
			}
			
			
		}
	   
	   
	}
	@Then("^Navigate to Adchoices icon$")
	public void navigate_to_Adchoices_icon() throws Throwable {
		if(clm<count) {
			WebElement ad = dcf.adChoices();
			   if(ad!=null) {
				   dcf.movetoelement(ad);
				   dcf.movetopageend();
				   try {
					ad.click();
					if(brand.equals("4")||(brand.equals("2"))) {
						   dcf.setExcelData("Lincoln", clm, 4, "Pass"); 
					   }else {
					   dcf.setExcelData("Ford", clm, 4, "Pass");
					   }
				} catch (Exception e) {
					logger.info("Cant Click Icon");
					if(brand.equals("4")||(brand.equals("2"))) {
						   dcf.setExcelData("Lincoln", clm, 5, "Not Validated"); 
						   dcf.setExcelData("Lincoln", clm, 6, "Not Validated");
						   dcf.setExcelData("Lincoln", clm, 4, "Pass");
					   }else {
						   dcf.setExcelData("Ford", clm, 5, "Not Validated");
						   dcf.setExcelData("Ford", clm, 6, "Not Validated");
						   dcf.setExcelData("Ford", clm, 4, "Pass");
					   }
					   clm++;
					   parse_UDL_Parameters();
				}
				   
			   }
			   else {
				   logger.info("No Adchoices icon");
				   if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 4, "Fail"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 4, "Fail");
				   }
				   if(flag) { // added this branch condition if ford validation fails and brand = 3
					   brand="4";					   
					   flag = false;
						launch_Dealersite();
				   }else {
				   clm++;
				   parse_UDL_Parameters();
				   }
			   }
			   verify_FordDirect_Logo();
			   click_on_Privacy_Statement(); 
		}
	   
	}

	
	@Then("^Verify FordDirect Logo$")
	public void verify_FordDirect_Logo() throws Throwable {
		if(clm<count) {
			WebElement fdl = dcf.FDLogo();
			if(fdl!=null) {
				logger.info("FordDirect Logo is present");
				if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 5, "Pass"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 5, "Pass");
				   }
			}
			else {
				logger.info("FordDirect Logo is missing");
				if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 5, "Fail"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 5, "Fail");
				   }
			}
			
		}
	}
	
	@Then("^click on Privacy Statement$")
	public void click_on_Privacy_Statement() throws Throwable {
		if(clm<count) {
			WebElement fp = dcf.fordprivacy();
			   if(fp!=null) {
				   dcf.movetoelement(fp);
				   try {
					fp.click();
					logger.info("Click on Privacy Link is Success");
					   validate_Page();
				} catch (Exception e) {
					logger.info("Cant Click on Privacy link");
					if(brand.equals("4")||(brand.equals("2"))) {
						   dcf.setExcelData("Lincoln", clm, 6, "Not Validated"); 
					   }else {
					   dcf.setExcelData("Ford", clm, 6, "Not Validated");
					   }
					   if(flag) {
						   brand="4";					   
						   flag = false;
							launch_Dealersite();
					   }else {
						   clm++;
						   parse_UDL_Parameters();
					   }
				}
				   
			   }
			   else {
				   logger.info("No Privacy Page / ADchoices Frame");
				   if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 6, "Fail"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 6, "Fail");
				   }
				   if(flag) {
					   brand="4";					   
					   flag = false;
						launch_Dealersite();
				   }else {
					   clm++;
					   parse_UDL_Parameters();
				   }
			   }
	   
		   
	   }
	}

	@Then("^Validate Page$")
	public void validate_Page() throws Throwable {
		if(clm<count) {
			Boolean result = dcf.privacyverify();
			if(result) {
				if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 6, "Pass"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 6, "Pass");
				   }
				   if(flag) {
					   brand="4";					   
					   flag = false;
						launch_Dealersite();
				   }else {
					   clm++;
					   parse_UDL_Parameters();
				   }
			}
			else {
				if(brand.equals("4")||(brand.equals("2"))) {
					   dcf.setExcelData("Lincoln", clm, 6, "Fail"); 
				   }else {
				   dcf.setExcelData("Ford", clm, 6, "Fail");
				   }
				   if(flag) {
					   brand="4";	
					   flag = false;
						launch_Dealersite();
				   }else {
					   clm++;
					   parse_UDL_Parameters();
				   }
				   
			}
		}
	   
	}

}
