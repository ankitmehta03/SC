package dcqa.stepDefinitions;

import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.log4j.Logger;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import dcqa.functions.DCfunctions;
import dcqa.utility.ExcelReadWrite;

public class StandardURL {
	static {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh.mm");
	    System.setProperty("current.date", dateFormat.format(new Date()));
	}	

	DCfunctions dcf = new DCfunctions();
	ExcelReadWrite er = new ExcelReadWrite();
	public String pacode,paparsed,platform,brand,dlurl;
	public int rowl=0,col,count,clm =1;
	public String PAcode;
	public Boolean flag = false;
	final static Logger logger = Logger.getLogger(StandardURL.class);

	
	@Given("^Launch chrome Browser$")
	public void launch_chrome_Browser() throws Throwable {
		dcf.launchChrome();
		logger.info("Chrome Launched");
	}

	@Then("^Read PAcode from Excel data file$")
	public void read_PAcode_from_Excel_data_file() throws Throwable {
		dcf.readExcel("StandardURL.xlsx");
		count=dcf.rowcnt;
		logger.info("Total PACode to execute: "+count);
	}

	@Then("^Parse UDL Parameters for PACode$")
	public void parse_UDL_Parameters_for_PACode() throws Throwable {
		if(clm<count) {	
			brand=null;
			PAcode = dcf.getExcelData("Ford", clm, 0); 
			logger.info("\nPACode to Validate: "+PAcode+" From row: "+(clm+1));
			pacode = dcf.parsepacode(PAcode);
			dcf.parsUDL(pacode, clm);
			brand = dcf.brnd;
			dlurl = DCfunctions.DealerURL;
			if((dlurl==null)&&(dlurl.length()>10)){
				logger.info("PA code "+pacode+" returned null results from UDL");
				clm++;
				parse_UDL_Parameters_for_PACode();
			}else {
				if(brand.equals("3")) {
					flag=true;				
				}
				
				launch_Dealersite_URL();
			}
			
		}
	}

	@Then("^Launch Dealersite URL$")
	public void launch_Dealersite_URL() throws Throwable {
		if(clm<count) {
			dcf.launchDealer(brand);
			if(dcf.sitecheck.equals("true")) {
				identify_Dealersite_Platform_after_Launch();
			}else {
				logger.info("Null Dealer URL Skipping PAcode"+pacode);
				clm++;
				parse_UDL_Parameters_for_PACode();
			}
			
		}
	}

	@Then("^Identify Dealersite Platform after Launch$")
	public void identify_Dealersite_Platform_after_Launch() throws Throwable {
		if(clm<count) {
			platform = null;
			if(brand.equals("4")||(brand.equals("2"))) {
				rowl++;
				platform = dcf.identifyPlatform(clm);
				//platform = dcf.lpltfm;
				if(platform.equals(null)) {
					platform = dcf.lpltfm;
				}				
				dcf.setExcelData("Lincoln", clm, 2, platform);
				navigate_to_Service_standard_URL_and_validate();
			}
			
			else {
				platform = dcf.identifyPlatform(clm);
				navigate_to_Service_standard_URL_and_validate();
			}
			
			
		}
	}

	@Then("^Navigate to Service standard URL and validate$")
	public void navigate_to_Service_standard_URL_and_validate() throws Throwable {
	    if(clm<count) {
	    	dcf.stndURLservice(brand);
	    	int cp = dcf.checkpage();
	    	if(cp<3) {
	    		logger.info("Page loaded Successfully");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 4, "Pass");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 4, "Pass");
	    		}
	    	}
	    	else {
	    		logger.info("Page not loaded");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 4, "Fail");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 4, "Fail");
	    		}
	    	}
	    	navigate_to_New_inventory_Page_and_validate();
	    }
	}

	@Then("^Navigate to New inventory Page and validate$")
	public void navigate_to_New_inventory_Page_and_validate() throws Throwable {
		if(clm<count) {
	    	dcf.stndURLnewinv(brand);
	    	int cp = dcf.checkpage();
	    	if(cp<3) {
	    		logger.info("Page loaded Successfully");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 5, "Pass");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 5, "Pass");
	    		}
	    	}
	    	else {
	    		logger.info("Page not loaded");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 5, "Fail");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 5, "Fail");
	    		}
	    	}
	    	navigate_to_Used_inventory_Page_and_validate();
	    }
	}

	@Then("^Navigate to Used inventory Page and validate$")
	public void navigate_to_Used_inventory_Page_and_validate() throws Throwable {
		if(clm<count) {
	    	dcf.stndURLusedinv(brand);
	    	int cp = dcf.checkpage();
	    	if(cp<3) {
	    		logger.info("Page loaded Successfully");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 6, "Pass");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 6, "Pass");
	    		}
	    	}
	    	else {
	    		logger.info("Page not loaded");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 6, "Fail");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 6, "Fail");
	    		}
	    	}
	    	navigate_to_Hours_Page_and_validate();
	    }
	}

	@Then("^Navigate to Hours Page and validate$")
	public void navigate_to_Hours_Page_and_validate() throws Throwable {
		if(clm<count) {
	    	dcf.stndURLhours(brand);
	    	int cp = dcf.checkpage();
	    	if(cp<3) {
	    		logger.info("Page loaded Successfully");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 7, "Pass");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 7, "Pass");
	    		}
	    	}
	    	else {
	    		logger.info("Page not loaded");
	    		if(brand.equals("4")||(brand.equals("2"))) {
	    			dcf.setExcelData("Lincoln", clm, 7, "Fail");
	    		}
	    		if(brand.equals("3")||(brand.equals("1"))) {
	    			dcf.setExcelData("Ford", clm, 7, "Fail");
	    		}
	    	}
	    	if(flag) {
				brand="4";
				flag = false;
				launch_Dealersite_URL();
				
			}
			else {
				clm++;				
				parse_UDL_Parameters_for_PACode();
			}
	    }

		
		
	}

	
}
