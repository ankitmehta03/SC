package dcqa.runner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
			//features = "classpath:features/Smartt.feature",
			//features = "classpath:features/OAR.feature",
			//features = "classpath:features/Autoalert.feature",
			//features = "classpath:features/TagTest.feature",
			//features = "classpath:features/Adchoices.feature",
			//features = "classpath:features/StandardURL.feature",
					features = "classpath:features/FacebookDAA.feature",
			glue = {"dcqa.stepDefinitions"},
			//tags= {"@CheckPoint,@LaunchDealer"},
			dryRun = false
		        )
public class TestRunner {

}
