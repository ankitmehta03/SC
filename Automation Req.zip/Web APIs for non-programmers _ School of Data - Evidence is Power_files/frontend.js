jQuery(document).ready(function($) {

	// Frontend JS

});